'use client';

import { useState } from 'react';
import Navigation from '../components/Navigation';
import Footer from '../components/Footer';
import Link from 'next/link';

interface LeadList {
  id: string;
  name: string;
  count: number;
}

export default function MessagePage() {
  const [selectedList, setSelectedList] = useState('');
  const [campaignName, setCampaignName] = useState('');
  const [messageTemplate, setMessageTemplate] = useState('');
  const [savingStatus, setSavingStatus] = useState<'idle' | 'saving' | 'saved'>('idle');

  // Mock data for lead lists
  const leadLists: LeadList[] = [
    { id: '1', name: 'Fitness Influencers', count: 126 },
    { id: '2', name: 'Beauty Bloggers', count: 87 },
    { id: '3', name: 'Tech Reviewers', count: 54 },
  ];

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!selectedList || !campaignName || !messageTemplate) {
      alert('Please fill all required fields');
      return;
    }
    
    setSavingStatus('saving');
    
    // Simulate saving with timeout
    setTimeout(() => {
      setSavingStatus('saved');
      
      // Redirect to dashboard after saving
      setTimeout(() => {
        window.location.href = '/dashboard';
      }, 1000);
    }, 1500);
  };

  // Example variables that can be used in the message template
  const exampleVariables = [
    { name: '{name}', description: 'Influencer\'s name' },
    { name: '{username}', description: 'Instagram username' },
    { name: '{followers}', description: 'Follower count' },
    { name: '{brand}', description: 'Your brand name' },
  ];

  return (
    <div className="flex flex-col min-h-screen bg-black">
      <Navigation />
      
      <main className="flex-grow pt-24 pb-20">
        <div className="container mx-auto px-4">
          {/* Page Header */}
          <div className="mb-10">
            <h1 className="heading-lg mb-2">Create Messaging Campaign</h1>
            <p className="text-gray-400">Send personalized messages to your target Instagram influencers</p>
          </div>
          
          {/* Campaign Form */}
          <form onSubmit={handleSubmit} className="card">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
              <div>
                <label htmlFor="campaignName" className="block mb-2 text-sm font-medium text-gray-300">
                  Campaign Name
                </label>
                <input
                  type="text"
                  id="campaignName"
                  value={campaignName}
                  onChange={(e) => setCampaignName(e.target.value)}
                  placeholder="e.g. Summer Product Launch"
                  className="input-field"
                  required
                />
              </div>
              
              <div>
                <label htmlFor="leadList" className="block mb-2 text-sm font-medium text-gray-300">
                  Select Lead List
                </label>
                <select
                  id="leadList"
                  value={selectedList}
                  onChange={(e) => setSelectedList(e.target.value)}
                  className="input-field"
                  required
                >
                  <option value="">Select a list</option>
                  {leadLists.map((list) => (
                    <option key={list.id} value={list.id}>
                      {list.name} ({list.count} leads)
                    </option>
                  ))}
                </select>
              </div>
            </div>
            
            <div className="mb-6">
              <label htmlFor="messageTemplate" className="block mb-2 text-sm font-medium text-gray-300">
                Message Template
              </label>
              <div className="flex flex-col md:flex-row gap-6">
                <div className="w-full md:w-2/3">
                  <textarea
                    id="messageTemplate"
                    value={messageTemplate}
                    onChange={(e) => setMessageTemplate(e.target.value)}
                    placeholder="Hi {name}, I noticed your amazing content on Instagram. I think our brand would be a perfect fit for your audience..."
                    className="input-field min-h-[200px]"
                    required
                  ></textarea>
                  <p className="mt-2 text-xs text-gray-500">Use variables like {'{name}'} to personalize your message</p>
                </div>
                
                <div className="w-full md:w-1/3 bg-gray-900/50 rounded-lg p-4 border border-gray-800">
                  <h4 className="text-sm font-medium text-gray-300 mb-3">Available Variables</h4>
                  <ul className="space-y-2">
                    {exampleVariables.map((variable, index) => (
                      <li key={index} className="text-xs">
                        <span className="text-white font-mono">{variable.name}</span>
                        <span className="text-gray-500 ml-2">- {variable.description}</span>
                      </li>
                    ))}
                  </ul>
                  <div className="mt-4 pt-4 border-t border-gray-800">
                    <h4 className="text-sm font-medium text-gray-300 mb-3">Preview</h4>
                    <div className="p-3 bg-gray-900 rounded border border-gray-700 text-xs">
                      {messageTemplate
                        ? messageTemplate
                            .replace(/{name}/g, 'Alex')
                            .replace(/{username}/g, 'fitness_guru')
                            .replace(/{followers}/g, '23,500')
                            .replace(/{brand}/g, 'Cresci')
                        : 'Your message preview will appear here...'}
                    </div>
                  </div>
                </div>
              </div>
            </div>
            
            <div className="flex justify-between items-center border-t border-gray-800 pt-6">
              <Link href="/dashboard" className="text-gray-400 hover:text-white transition-colors">
                Cancel
              </Link>
              <button
                type="submit"
                className="primary-button"
                disabled={savingStatus !== 'idle'}
              >
                {savingStatus === 'saving'
                  ? 'Creating Campaign...'
                  : savingStatus === 'saved'
                  ? 'Campaign Created!'
                  : 'Create Campaign'}
              </button>
            </div>
          </form>
        </div>
      </main>

      <Footer />
    </div>
  );
} 