import React from 'react';

interface EmailTemplateProps {
  name: string;
  email?: string; // Made optional and added comment to indicate it's for future use
}

export const EmailTemplate = ({
  name
}: EmailTemplateProps): React.ReactElement => (
  <div style={{ fontFamily: 'Arial, sans-serif', maxWidth: '600px', margin: '0 auto' }}>
    <h1 style={{ color: '#333', fontSize: '24px' }}>yoo</h1>
    
    <p style={{ fontSize: '16px', color: '#555', marginTop: '24px' }}>
      Thanks for signing up{name ? `, ${name}` : ''}!
    </p>
    
    <p style={{ fontSize: '16px', color: '#555', marginTop: '16px' }}>
      We&apos;ll keep you updated with all the cool stuff we&apos;ve got coming. Big things are on the way, and we&apos;re hyped to have you along for the ride.
    </p>
    
    <p style={{ fontSize: '16px', color: '#555', marginTop: '16px' }}>
      Seriously, your support means a lot. Let&apos;s build something amazing together and dont forget to send any feautures that would make the app better for you.
    </p>
    
    <div style={{ marginTop: '32px', borderTop: '1px solid #eee', paddingTop: '16px' }}>
      <p style={{ fontSize: '16px', color: '#555', margin: '0' }}>
        Thanks,
      </p>
      <p style={{ fontSize: '16px', color: '#555', margin: '8px 0 0 0' }}>
        Cresci
      </p>
    </div>
  </div>
); 