'use client';

import { useState, useEffect, useRef } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import Link from 'next/link';

interface UserIconProps {
  email: string;
  name?: string;
}

const UserIcon = ({ email, name }: UserIconProps) => {
  const [isOpen, setIsOpen] = useState(false);
  const dropdownRef = useRef<HTMLDivElement>(null);
  
  // Close dropdown when clicking outside
  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (dropdownRef.current && !dropdownRef.current.contains(event.target as Node)) {
        setIsOpen(false);
      }
    };
    
    document.addEventListener('mousedown', handleClickOutside);
    return () => {
      document.removeEventListener('mousedown', handleClickOutside);
    };
  }, []);
  
  // Create initials from name or email
  const getInitials = () => {
    if (name && name.length > 0) {
      const nameParts = name.split(' ');
      if (nameParts.length === 1) {
        return nameParts[0].charAt(0).toUpperCase();
      } else {
        return (nameParts[0].charAt(0) + nameParts[nameParts.length - 1].charAt(0)).toUpperCase();
      }
    }
    
    // Fallback to email
    return email.charAt(0).toUpperCase();
  };
  
  const handleLogout = () => {
    // In a real app, you'd clear tokens, session data, etc.
    localStorage.removeItem('user');
    window.location.href = '/';
  };
  
  return (
    <div className="relative" ref={dropdownRef}>
      {/* This matches the same gradient style as the Get Started button */}
      <div className="relative p-[2px] rounded-full group hover:shadow-lg hover:shadow-blue-500/30 transition-all duration-300">
        {/* Gradient border */}
        <div className="absolute inset-0 rounded-full bg-gradient-to-r from-blue-600 via-purple-600 to-blue-600 bg-[length:200%_200%] animate-gradient-x"></div>
        
        {/* Black circle with initials */}
        <motion.button
          onClick={() => setIsOpen(!isOpen)}
          className="relative flex items-center justify-center w-9 h-9 rounded-full bg-black text-white font-semibold z-10"
          whileHover={{ scale: 1.05 }}
          whileTap={{ scale: 0.95 }}
          aria-label="User menu"
        >
          {getInitials()}
        </motion.button>
      </div>
      
      <AnimatePresence>
        {isOpen && (
          <motion.div
            initial={{ opacity: 0, scale: 0.95, y: -10 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.95, y: -10 }}
            transition={{ duration: 0.2 }}
            className="absolute right-0 mt-2 w-64 rounded-lg bg-gray-900 border border-gray-800 shadow-lg py-2 z-50"
          >
            <div className="px-4 py-3 border-b border-gray-800">
              {name && <p className="font-medium text-white">{name}</p>}
              <p className="text-sm text-gray-400 truncate">{email}</p>
            </div>
            
            <div className="px-2 py-2">
              <Link href="/settings" className="block px-4 py-2 text-sm text-gray-300 rounded-md hover:bg-gray-800 transition-colors">
                Settings
              </Link>
              <button
                onClick={handleLogout}
                className="w-full text-left px-4 py-2 text-sm text-red-400 rounded-md hover:bg-gray-800 transition-colors"
              >
                Log out
              </button>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
};

export default UserIcon; 