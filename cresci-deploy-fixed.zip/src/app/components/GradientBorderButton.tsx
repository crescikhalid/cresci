'use client';

import React from 'react';
import { motion } from 'framer-motion';
import Link from 'next/link';

interface GradientBorderButtonProps {
  href: string;
  text: string;
  isActive: boolean;
}

const GradientBorderButton: React.FC<GradientBorderButtonProps> = ({ href, text, isActive }) => {
  return (
    <motion.div 
      className="relative inline-block"
      whileHover={{ 
        scale: 1.03,
      }}
      whileTap={{ scale: 0.97 }}
      transition={{
        type: "spring",
        stiffness: 600,
        damping: 15
      }}
    >
      {/* Enhanced animated gradient border with synchronized hover effect */}
      <motion.div
        className="absolute inset-0 rounded-full opacity-90 group-hover:opacity-100 blur-[1.5px] group-hover:blur-[2px] transition-all duration-200"
        animate={{
          background: [
            'linear-gradient(90deg, #8B5CF6, #3B82F6, #14B8A6)',
            'linear-gradient(180deg, #3B82F6, #14B8A6, #8B5CF6)',
            'linear-gradient(270deg, #14B8A6, #8B5CF6, #3B82F6)',
            'linear-gradient(360deg, #8B5CF6, #3B82F6, #14B8A6)',
          ],
        }}
        transition={{ 
          duration: 8, 
          repeat: Infinity, 
          repeatType: "loop",
        }}
      />
      
      {/* Inner button with synchronized hover effect */}
      <div className="relative rounded-full p-[2px]">
        <Link href={href} className="block" prefetch={true}>
          <div
            className={`relative px-6 py-2 rounded-full flex items-center justify-center ${
              isActive 
                ? 'bg-black text-white hover:bg-black/90' 
                : 'bg-gray-900/90 text-gray-400'
            }`}
          >
            <span className="text-sm font-medium">{text}</span>
          </div>
        </Link>
      </div>
    </motion.div>
  );
};

export default GradientBorderButton; 