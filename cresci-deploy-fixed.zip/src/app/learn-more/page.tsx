'use client';

import { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import Navigation from '../components/Navigation';
import Footer from '../components/Footer';
import Link from 'next/link';
import GradientBorderButton from '../components/GradientBorderButton';

const containerVariants = {
  hidden: { opacity: 0 },
  visible: {
    opacity: 1,
    transition: {
      staggerChildren: 0.1
    }
  }
};

const itemVariants = {
  hidden: { opacity: 0, y: 20 },
  visible: {
    opacity: 1,
    y: 0,
    transition: {
      duration: 0.5
    }
  }
};

export default function LearnMore() {
  const [isVisible, setIsVisible] = useState(false);

  useEffect(() => {
    // Set visible after a small delay for animation purposes
    const timer = setTimeout(() => {
      setIsVisible(true);
    }, 100);
    
    return () => clearTimeout(timer);
  }, []);

  const features = [
    {
      title: "Automated Outreach",
      description: "Our platform handles the entire outreach process from start to finish. Create campaigns, send personalized messages, and track responses automatically.",
      icon: "📧",
      delay: 0.1
    },
    {
      title: "Lead Management",
      description: "Organize prospects into custom lists, add notes, track communication history, and manage your entire client pipeline in one place.",
      icon: "👥",
      delay: 0.2
    },
    {
      title: "AI-Powered Templates",
      description: "Create message templates with dynamic personalization variables. Leverage AI to optimize your messaging and boost response rates.",
      icon: "🤖",
      delay: 0.3
    },
    {
      title: "Analytics & Insights",
      description: "Track open rates, response rates, and conversion metrics. Get data-driven insights to optimize your outreach strategy.",
      icon: "📊",
      delay: 0.4
    },
    {
      title: "Integration Ecosystem",
      description: "Connect with your favorite tools including CRMs, email providers, and more. Keep your workflow streamlined and efficient.",
      icon: "🔄",
      delay: 0.5
    },
    {
      title: "Scalable Campaigns",
      description: "Whether you're reaching out to 10 prospects or 10,000, our platform scales with your needs while maintaining personalization.",
      icon: "📈",
      delay: 0.6
    }
  ];

  return (
    <div className="flex flex-col min-h-screen bg-black">
      <Navigation />
      
      <main className="flex-grow">
        {/* Hero Section */}
        <section className="pt-32 pb-20">
          <div className="container mx-auto px-4">
            <motion.div
              className="max-w-4xl mx-auto text-center"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: isVisible ? 1 : 0, y: isVisible ? 0 : 20 }}
              transition={{ duration: 0.7 }}
            >
              <h1 className="text-5xl sm:text-6xl font-bold mb-6 text-white">
                Learn more about Cresci
              </h1>
              <p className="text-xl text-gray-300 mb-12 max-w-3xl mx-auto">
                Discover how our platform helps businesses automate their outreach, 
                scale their operations, and drive more revenue.
              </p>
            </motion.div>
          </div>
        </section>

        {/* Features Grid Section */}
        <section className="py-20">
          <div className="container mx-auto px-4">
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8 max-w-6xl mx-auto">
              {features.map((feature, index) => (
                <motion.div
                  key={index}
                  className="bg-gray-900 rounded-lg p-6 border border-gray-800 h-full"
                  initial={{ opacity: 0, y: 30 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.5, delay: feature.delay }}
                  whileHover={{ 
                    y: -10, 
                    boxShadow: "0 15px 30px rgba(75, 85, 99, 0.3)",
                    transition: { duration: 0.2 }
                  }}
                >
                  <div className="text-3xl mb-4">{feature.icon}</div>
                  <h3 className="text-xl font-semibold mb-3 text-white">{feature.title}</h3>
                  <p className="text-gray-400">{feature.description}</p>
                </motion.div>
              ))}
            </div>
          </div>
        </section>
        
        {/* How It Works Section */}
        <section className="py-20 bg-gray-900">
          <div className="container mx-auto px-4">
            <motion.div
              className="max-w-4xl mx-auto"
              initial={{ opacity: 0 }}
              whileInView={{ opacity: 1 }}
              viewport={{ once: true }}
              transition={{ duration: 0.7 }}
            >
              <h2 className="text-4xl font-bold mb-12 text-center text-white">
                How It Works
              </h2>
              
              <div className="space-y-12">
                <motion.div 
                  className="flex flex-col md:flex-row items-center gap-8"
                  initial={{ opacity: 0, x: -30 }}
                  whileInView={{ opacity: 1, x: 0 }}
                  viewport={{ once: true }}
                  transition={{ duration: 0.5 }}
                >
                  <div className="md:w-2/5 flex justify-center">
                    <div className="w-20 h-20 rounded-full bg-white/10 flex items-center justify-center text-white text-2xl font-bold">
                      1
                    </div>
                  </div>
                  <div className="md:w-3/5">
                    <h3 className="text-2xl font-bold mb-4 text-white">Create Your Campaign</h3>
                    <p className="text-gray-300">
                      Define your target audience, set up your outreach parameters, and create personalized message templates 
                      with dynamic variables that adapt to each recipient.
                    </p>
                  </div>
                </motion.div>
                
                <motion.div 
                  className="flex flex-col md:flex-row items-center gap-8"
                  initial={{ opacity: 0, x: 30 }}
                  whileInView={{ opacity: 1, x: 0 }}
                  viewport={{ once: true }}
                  transition={{ duration: 0.5, delay: 0.2 }}
                >
                  <div className="md:w-2/5 flex justify-center md:order-last">
                    <div className="w-20 h-20 rounded-full bg-white/10 flex items-center justify-center text-white text-2xl font-bold">
                      2
                    </div>
                  </div>
                  <div className="md:w-3/5">
                    <h3 className="text-2xl font-bold mb-4 text-white">Automate Your Outreach</h3>
                    <p className="text-gray-300">
                      Our platform handles the sending process, following up with non-responders, 
                      and managing conversations - all while maintaining a personal touch.
                    </p>
                  </div>
                </motion.div>
                
                <motion.div 
                  className="flex flex-col md:flex-row items-center gap-8"
                  initial={{ opacity: 0, x: -30 }}
                  whileInView={{ opacity: 1, x: 0 }}
                  viewport={{ once: true }}
                  transition={{ duration: 0.5, delay: 0.4 }}
                >
                  <div className="md:w-2/5 flex justify-center">
                    <div className="w-20 h-20 rounded-full bg-white/10 flex items-center justify-center text-white text-2xl font-bold">
                      3
                    </div>
                  </div>
                  <div className="md:w-3/5">
                    <h3 className="text-2xl font-bold mb-4 text-white">Track & Optimize</h3>
                    <p className="text-gray-300">
                      Monitor campaign performance, analyze response rates, and use AI-powered insights 
                      to continuously improve your outreach strategies for better results.
                    </p>
                  </div>
                </motion.div>
              </div>
            </motion.div>
          </div>
        </section>
        
        {/* CTA Section */}
        <section className="py-20 bg-black border-t border-gray-800">
          <div className="container mx-auto px-4">
            <motion.div 
              className="max-w-3xl mx-auto text-center"
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.7 }}
            >
              <h2 className="text-4xl font-bold mb-6 text-white">
                Ready to get started?
              </h2>
              <p className="text-lg text-gray-300 mb-10">
                Join our waitlist to be the first to know when we launch. 
                Early adopters will receive special pricing and exclusive features.
              </p>
              <GradientBorderButton href="/" text="Back to Home" isActive={true} />
            </motion.div>
          </div>
        </section>
      </main>

      <Footer />
    </div>
  );
} 