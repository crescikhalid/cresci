import { createClient } from '@supabase/supabase-js';
import { NextResponse } from 'next/server';
import { Resend } from 'resend';
import { EmailTemplate } from '@/app/components/EmailTemplate';

const resend = new Resend(process.env.RESEND_API_KEY);
const supabase = createClient(
  process.env.NEXT_PUBLIC_SUPABASE_URL!,
  process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!
);

// We'll query Supabase instead of using an in-memory variable
export async function GET() {
  try {
    // Get the count of signups from Supabase
    const { count, error } = await supabase
      .from('signups')
      .select('*', { count: 'exact', head: true });
    
    if (error) throw error;
    
    // If count is null, return 0
    return NextResponse.json({ count: count || 0 });
  } catch (error) {
    console.error('Error getting signup count:', error);
    return NextResponse.json({ count: 0 });
  }
}

export async function POST(request: Request) {
  try {
    const body = await request.json();
    const { email, name } = body;
    
    // Validate input
    if (!email) {
      return NextResponse.json(
        { error: 'Email is required' },
        { status: 400 }
      );
    }
    
    // Store email in Supabase
    const { error: dbError } = await supabase
      .from('signups')
      .insert([{ email, created_at: new Date().toISOString() }]);

    if (dbError) throw dbError;
    
    // Get updated count after insert
    const { count, error: countError } = await supabase
      .from('signups')
      .select('*', { count: 'exact', head: true });
      
    if (countError) throw countError;

    // Send welcome email
    try {
      await resend.emails.send({
        from: 'Cresci <onboarding@resend.dev>',
        to: email,
        subject: `yoo`,
        react: EmailTemplate({ name: '' }),
      });
    } catch (emailError) {
      console.error('Error sending welcome email:', emailError);
      // Don't throw the error - we still want to return success if the signup was stored
    }

    return NextResponse.json({ 
      success: true, 
      message: 'Signup successful',
      count: count || 0
    });
  } catch (error) {
    console.error('Signup error:', error);
    return NextResponse.json(
      { error: 'Failed to process signup' },
      { status: 500 }
    );
  }
} 