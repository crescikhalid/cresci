'use client';

import { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import Link from 'next/link';
import Navigation from '../components/Navigation';
import Footer from '../components/Footer';
import GradientBorderButton from '@/app/components/GradientBorderButton';

export default function EarlyAccess() {
  const [openFaq, setOpenFaq] = useState<number | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const [checkoutError, setCheckoutError] = useState<string | null>(null);
  
  const toggleFaq = (index: number) => {
    setOpenFaq(openFaq === index ? null : index);
  };
  
  const faqItems = [
    {
      question: "What happens after I pay?",
      answer: "I'll email you before anyone else when the beta's ready."
    },
    {
      question: "Refunds?",
      answer: "Yeah, 100% refundable until launch. No stress."
    },
    {
      question: "Where can I see updates?",
      answer: "I'm posting progress on"
    }
  ];

  const handleCheckout = async () => {
    try {
      setIsLoading(true);
      setCheckoutError(null);
      
      const response = await fetch('/api/create-checkout', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
      });
      
      const data = await response.json();
      
      if (data.success && data.url) {
        window.location.href = data.url;
      } else {
        setCheckoutError('Unable to start checkout. Please try again.');
        setIsLoading(false);
      }
    } catch (error) {
      console.error('Error creating checkout:', error);
      setCheckoutError('An error occurred. Please try again later.');
      setIsLoading(false);
    }
  };

  return (
    <div className="flex flex-col min-h-screen bg-black">
      <Navigation />
      
      <main className="flex-grow">
        <section className="relative min-h-screen flex items-center justify-center overflow-hidden pt-24">
          <div className="container mx-auto px-6">
            <motion.div 
              className="max-w-2xl mx-auto"
              initial={{ opacity: 0, y: 30 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.7 }}
            >
              <div className="bg-gray-900/80 backdrop-blur-md p-8 rounded-xl border border-gray-800">
                <h1 className="text-3xl sm:text-4xl font-bold mb-3 text-white">
                  yo, you're on the list 👀
                </h1>
                
                <h2 className="text-xl sm:text-2xl font-bold mb-6 text-gray-300">
                  real quick wanna lock in early access + lifetime deal?
                </h2>
                
                <p className="text-gray-300 mb-8">
                  I'm building a tool that scrapes niche IG leads and auto-DMs them. If you wanna be one of the first to use it (and help shape it), I'm offering a limited $10 early bird deal.
                </p>
                
                <div className="mb-8 space-y-3">
                  <div className="flex items-start">
                    <div className="flex-shrink-0 mt-1">
                      <div className="h-5 w-5 rounded-full bg-gradient-to-r from-purple-500 via-blue-500 to-teal-500"></div>
                    </div>
                    <div className="ml-3">
                      <p className="text-white">one-time $10 → lifetime access</p>
                    </div>
                  </div>
                  
                  <div className="flex items-start">
                    <div className="flex-shrink-0 mt-1">
                      <div className="h-5 w-5 rounded-full bg-gradient-to-r from-purple-500 via-blue-500 to-teal-500"></div>
                    </div>
                    <div className="ml-3">
                      <p className="text-white">get access before launch</p>
                    </div>
                  </div>
                  
                  <div className="flex items-start">
                    <div className="flex-shrink-0 mt-1">
                      <div className="h-5 w-5 rounded-full bg-gradient-to-r from-purple-500 via-blue-500 to-teal-500"></div>
                    </div>
                    <div className="ml-3">
                      <p className="text-white">help shape the product</p>
                    </div>
                  </div>
                </div>
                
                <div className="mb-10 mt-8">
                  <motion.div
                    className="relative overflow-hidden rounded-lg"
                    whileHover={{ scale: 1.03 }}
                    whileTap={{ scale: 0.97 }}
                    transition={{
                      type: "spring",
                      stiffness: 400,
                      damping: 15
                    }}
                  >
                    {/* Gradient border/outline effect */}
                    <div className="absolute inset-0 rounded-lg opacity-90 bg-gradient-to-r from-purple-500 via-blue-500 to-teal-500" 
                      style={{ 
                        backgroundSize: "200% 200%",
                        animation: "gradientAnimation 6s linear infinite"
                      }}
                    />
                    <div className="relative m-[1.5px] rounded-lg overflow-hidden">
                      <button
                        onClick={handleCheckout}
                        className="w-full py-4 px-6 bg-gray-900 text-white font-medium rounded-lg transition-all duration-200 text-lg"
                        disabled={isLoading}
                      >
                        {isLoading ? (
                          <div className="flex items-center justify-center space-x-2">
                            <svg className="animate-spin h-5 w-5 mr-2 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                              <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                              <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                            </svg>
                            <span>Processing...</span>
                          </div>
                        ) : (
                          <span>Reserve Your Spot</span>
                        )}
                      </button>
                    </div>
                  </motion.div>
                </div>
                
                {checkoutError && (
                  <div className="mt-3 text-red-400 text-sm text-center">
                    {checkoutError}
                    <button 
                      className="ml-2 text-blue-400 hover:text-blue-300 underline"
                      onClick={() => setCheckoutError(null)}
                    >
                      Try again
                    </button>
                  </div>
                )}
                
                {/* FAQ Section */}
                <div className="mt-12">
                  <h3 className="text-xl font-semibold mb-6 text-white">FAQ</h3>
                  
                  <div className="space-y-4">
                    {faqItems.map((item, index) => (
                      <div 
                        key={index} 
                        className="border border-gray-800 rounded-lg overflow-hidden"
                      >
                        <button
                          className="w-full px-6 py-4 text-left bg-gray-900 text-white hover:bg-gray-800 transition-colors duration-200 flex justify-between items-center"
                          onClick={() => toggleFaq(index)}
                        >
                          <span>{item.question}</span>
                          <motion.svg
                            animate={{ rotate: openFaq === index ? 180 : 0 }}
                            transition={{ duration: 0.3, ease: "easeInOut" }}
                            className="w-5 h-5"
                            fill="none"
                            stroke="currentColor"
                            viewBox="0 0 24 24"
                            xmlns="http://www.w3.org/2000/svg"
                          >
                            <path
                              strokeLinecap="round"
                              strokeLinejoin="round"
                              strokeWidth="2"
                              d="M19 9l-7 7-7-7"
                            ></path>
                          </motion.svg>
                        </button>
                        
                        <AnimatePresence>
                          {openFaq === index && (
                            <motion.div
                              key={`faq-${index}`}
                              initial={{ height: 0 }}
                              animate={{ height: "auto" }}
                              exit={{ height: 0 }}
                              transition={{
                                duration: 0.25,
                                ease: "linear"
                              }}
                              className="bg-gray-800/50 overflow-hidden"
                            >
                              <div className="px-6 py-4">
                                {index === 2 ? (
                                  <div className="text-gray-300 flex items-center">
                                    {item.answer} 
                                    <Link href="https://instagram.com" className="ml-2 relative inline-block">
                                      <div className="absolute inset-0 rounded-full animate-pulse bg-gradient-to-r from-purple-500 via-blue-500 to-teal-500 opacity-70 blur-[2px]"></div>
                                      <svg 
                                        className="w-6 h-6 relative z-10" 
                                        fill="white" 
                                        xmlns="http://www.w3.org/2000/svg" 
                                        viewBox="0 0 448 512"
                                      >
                                        <path d="M224.1 141c-63.6 0-114.9 51.3-114.9 114.9s51.3 114.9 114.9 114.9S339 319.5 339 255.9 287.7 141 224.1 141zm0 189.6c-41.1 0-74.7-33.5-74.7-74.7s33.5-74.7 74.7-74.7 74.7 33.5 74.7 74.7-33.6 74.7-74.7 74.7zm146.4-194.3c0 14.9-12 26.8-26.8 26.8-14.9 0-26.8-12-26.8-26.8s12-26.8 26.8-26.8 26.8 12 26.8 26.8zm76.1 27.2c-1.7-35.9-9.9-67.7-36.2-93.9-26.2-26.2-58-34.4-93.9-36.2-37-2.1-147.9-2.1-184.9 0-35.8 1.7-67.6 9.9-93.9 36.1s-34.4 58-36.2 93.9c-2.1 37-2.1 147.9 0 184.9 1.7 35.9 9.9 67.7 36.2 93.9s58 34.4 93.9 36.2c37 2.1 147.9 2.1 184.9 0 35.9-1.7 67.7-9.9 93.9-36.2 26.2-26.2 34.4-58 36.2-93.9 2.1-37 2.1-147.8 0-184.8zM398.8 388c-7.8 19.6-22.9 34.7-42.6 42.6-29.5 11.7-99.5 9-132.1 9s-102.7 2.6-132.1-9c-19.6-7.8-34.7-22.9-42.6-42.6-11.7-29.5-9-99.5-9-132.1s-2.6-102.7 9-132.1c7.8-19.6 22.9-34.7 42.6-42.6 29.5-11.7 99.5-9 132.1-9s102.7-2.6 132.1 9c19.6 7.8 34.7 22.9 42.6 42.6 11.7 29.5 9 99.5 9 132.1s2.7 102.7-9 132.1z"/>
                                      </svg>
                                    </Link>
                                  </div>
                                ) : (
                                  <p className="text-gray-300">{item.answer}</p>
                                )}
                              </div>
                            </motion.div>
                          )}
                        </AnimatePresence>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            </motion.div>
          </div>
        </section>
      </main>

      <Footer />
    </div>
  );
} 