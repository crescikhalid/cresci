'use client';

import { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import Navigation from '../components/Navigation';
import Footer from '../components/Footer';
import Link from 'next/link';

export default function PricingPage() {
  const [isVisible, setIsVisible] = useState(false);

  useEffect(() => {
    // Set visible after a small delay for animation purposes
    const timer = setTimeout(() => {
      setIsVisible(true);
    }, 100);
    
    return () => clearTimeout(timer);
  }, []);

  return (
    <div className="flex flex-col min-h-screen bg-black">
      <Navigation />
      
      <main className="flex-grow">
        {/* Coming Soon Section */}
        <section className="py-40">
          <div className="container mx-auto px-4">
            <div className="relative max-w-4xl mx-auto">
              {/* Animated gradient bubbles */}
              <motion.div 
                className="absolute -top-20 -left-20 w-64 h-64 rounded-full bg-gradient-to-r from-purple-500 via-blue-500 to-teal-500 opacity-30 blur-xl"
                animate={{
                  scale: [1, 1.1, 1],
                  rotate: [0, 10, 0],
                }}
                transition={{
                  duration: 8,
                  repeat: Infinity,
                  repeatType: "reverse",
                  ease: "easeInOut"
                }}
              />
              <motion.div 
                className="absolute -bottom-20 -right-20 w-64 h-64 rounded-full bg-gradient-to-r from-blue-500 via-teal-500 to-purple-500 opacity-30 blur-xl"
                animate={{
                  scale: [1, 1.15, 1],
                  rotate: [0, -10, 0],
                }}
                transition={{
                  duration: 7,
                  repeat: Infinity,
                  repeatType: "reverse",
                  ease: "easeInOut",
                  delay: 0.5
                }}
              />
              
              {/* Coming Soon Content */}
              <div className="relative z-10 text-center">
                <motion.div 
                  initial={{ opacity: 0, y: 30 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.7, delay: 0.3 }}
                >
                  <h2 className="text-6xl font-bold mb-8 bg-gradient-to-r from-white via-gray-300 to-white bg-clip-text text-transparent leading-normal pb-2">
                    Coming Soon
                  </h2>
                  
                  <motion.div
                    className="inline-block"
                    whileHover={{ scale: 1.05 }}
                    whileTap={{ scale: 0.95 }}
                  >
                    <Link href="/signup" className="relative inline-block">
                      {/* Animated border */}
                      <motion.div
                        className="absolute inset-0 rounded-full opacity-80 blur-[2px]"
                        animate={{
                          background: [
                            'linear-gradient(90deg, #8B5CF6, #3B82F6, #14B8A6)',
                            'linear-gradient(180deg, #3B82F6, #14B8A6, #8B5CF6)',
                            'linear-gradient(270deg, #14B8A6, #8B5CF6, #3B82F6)',
                            'linear-gradient(360deg, #8B5CF6, #3B82F6, #14B8A6)',
                            'linear-gradient(90deg, #8B5CF6, #3B82F6, #14B8A6)',
                          ],
                        }}
                        transition={{ 
                          duration: 6, 
                          repeat: Infinity, 
                          repeatType: "loop" 
                        }}
                      />
                      
                      {/* Button content */}
                      <div className="relative rounded-full p-[2px]">
                        <div className="px-8 py-3 rounded-full bg-black text-white font-medium">
                          Join Waitlist
                        </div>
                      </div>
                    </Link>
                  </motion.div>
                </motion.div>
              </div>
            </div>
          </div>
        </section>
      </main>

      <Footer />
    </div>
  );
} 