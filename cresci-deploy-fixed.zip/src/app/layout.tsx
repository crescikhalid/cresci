import './globals.css'
import type { Metadata } from 'next'
import { Inter } from 'next/font/google'

const inter = Inter({ subsets: ['latin'] })

export const metadata: Metadata = {
  title: 'Cresci - Growth Operating Platform',
  description: 'Your all-in-one platform for automating outreach, scaling client acquisition, and driving revenue.',
  icons: {
    icon: '/favicon-transparent.svg',
  }
}

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en">
      <body className={inter.className}>{children}</body>
    </html>
  );
}
