'use client';

import { useState } from 'react';
import Navigation from '../components/Navigation';
import Footer from '../components/Footer';
import Link from 'next/link';

export default function ScrapePage() {
  const [niche, setNiche] = useState('');
  const [minFollowers, setMinFollowers] = useState(1000);
  const [maxFollowers, setMaxFollowers] = useState(100000);
  const [searchStatus, setSearchStatus] = useState<'idle' | 'searching' | 'complete'>('idle');
  const [results, setResults] = useState<any[]>([]);
  const [listName, setListName] = useState('');
  const [savingStatus, setSavingStatus] = useState<'idle' | 'saving' | 'saved'>('idle');

  const handleSearch = async (e: React.FormEvent) => {
    e.preventDefault();
    setSearchStatus('searching');
    
    // Simulate API call with timeout
    setTimeout(() => {
      // Mock data for demonstration
      const mockResults = [
        { id: '1', username: 'fitness_guru', name: 'Alex Johnson', followers: 23500, engagement: '4.2%', posts: 342, niches: ['Fitness', 'Nutrition'] },
        { id: '2', username: 'workout_daily', name: 'Sarah Smith', followers: 45800, engagement: '3.8%', posts: 521, niches: ['Fitness', 'Lifestyle'] },
        { id: '3', username: 'health_enthusiast', name: 'Mike Brown', followers: 12300, engagement: '5.1%', posts: 267, niches: ['Fitness', 'Health'] },
        { id: '4', username: 'gym_lover', name: 'Jessica Taylor', followers: 78600, engagement: '2.9%', posts: 643, niches: ['Fitness', 'Fashion'] },
        { id: '5', username: 'strength_coach', name: 'David Wilson', followers: 34200, engagement: '4.5%', posts: 412, niches: ['Fitness', 'Coaching'] },
      ];
      
      setResults(mockResults);
      setSearchStatus('complete');
    }, 2000);
  };

  const handleSaveList = () => {
    if (!listName.trim()) {
      alert('Please enter a name for your list');
      return;
    }
    
    setSavingStatus('saving');
    
    // Simulate saving with timeout
    setTimeout(() => {
      setSavingStatus('saved');
      
      // Redirect to dashboard after saving
      setTimeout(() => {
        window.location.href = '/dashboard';
      }, 1000);
    }, 1500);
  };

  return (
    <div className="flex flex-col min-h-screen bg-black">
      <Navigation />
      
      <main className="flex-grow pt-24 pb-20">
        <div className="container mx-auto px-4">
          {/* Page Header */}
          <div className="mb-10">
            <h1 className="heading-lg mb-2">Scrape Instagram Leads</h1>
            <p className="text-gray-400">Find Instagram influencers based on niche and follower count</p>
          </div>
          
          {/* Search Form */}
          <div className="card mb-10">
            <form onSubmit={handleSearch}>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
                <div>
                  <label htmlFor="niche" className="block mb-2 text-sm font-medium text-gray-300">
                    Niche / Category
                  </label>
                  <input
                    type="text"
                    id="niche"
                    value={niche}
                    onChange={(e) => setNiche(e.target.value)}
                    placeholder="e.g. fitness, beauty, technology"
                    className="input-field"
                    required
                  />
                  <p className="mt-2 text-xs text-gray-500">Enter a specific niche to target relevant influencers</p>
                </div>
                
                <div>
                  <label className="block mb-2 text-sm font-medium text-gray-300">
                    Follower Range
                  </label>
                  <div className="flex items-center gap-4 mb-2">
                    <input
                      type="number"
                      value={minFollowers}
                      onChange={(e) => setMinFollowers(Number(e.target.value))}
                      min="0"
                      className="input-field w-1/3"
                    />
                    <span className="text-gray-500">to</span>
                    <input
                      type="number"
                      value={maxFollowers}
                      onChange={(e) => setMaxFollowers(Number(e.target.value))}
                      min={minFollowers}
                      className="input-field w-1/3"
                    />
                  </div>
                  <div className="relative pt-1">
                    <input
                      type="range"
                      min="0"
                      max="1000000"
                      step="1000"
                      value={minFollowers}
                      onChange={(e) => setMinFollowers(Number(e.target.value))}
                      className="w-full h-2 bg-gray-700 rounded-lg appearance-none cursor-pointer range-sm"
                    />
                    <input
                      type="range"
                      min="0"
                      max="1000000"
                      step="1000"
                      value={maxFollowers}
                      onChange={(e) => setMaxFollowers(Number(e.target.value))}
                      className="w-full h-2 bg-gray-700 rounded-lg appearance-none cursor-pointer range-sm mt-2"
                    />
                  </div>
                  <p className="mt-2 text-xs text-gray-500">Select followers range to target micro, mid-tier, or macro influencers</p>
                </div>
              </div>
              
              <div className="flex justify-end">
                <button
                  type="submit"
                  className="primary-button flex items-center gap-2"
                  disabled={searchStatus === 'searching' || !niche.trim()}
                >
                  {searchStatus === 'searching' ? (
                    <>
                      <svg className="animate-spin h-4 w-4 text-black" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                        <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                        <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                      </svg>
                      Searching...
                    </>
                  ) : (
                    'Find Influencers'
                  )}
                </button>
              </div>
            </form>
          </div>
          
          {/* Results */}
          {searchStatus === 'complete' && (
            <div className="mb-10">
              <div className="flex flex-col sm:flex-row justify-between items-center mb-6">
                <h2 className="heading-md">Search Results</h2>
                <p className="text-gray-400">{results.length} influencers found</p>
              </div>
              
              <div className="bg-gray-900/40 rounded-lg border border-gray-800 overflow-hidden mb-8">
                <table className="w-full">
                  <thead>
                    <tr className="border-b border-gray-800">
                      <th className="py-3 px-4 text-left font-medium text-gray-300">Username</th>
                      <th className="py-3 px-4 text-left font-medium text-gray-300 hidden md:table-cell">Name</th>
                      <th className="py-3 px-4 text-left font-medium text-gray-300">Followers</th>
                      <th className="py-3 px-4 text-left font-medium text-gray-300 hidden md:table-cell">Engagement</th>
                      <th className="py-3 px-4 text-left font-medium text-gray-300 hidden md:table-cell">Posts</th>
                    </tr>
                  </thead>
                  <tbody>
                    {results.map((profile) => (
                      <tr key={profile.id} className="border-b border-gray-800 hover:bg-gray-800/50">
                        <td className="py-3 px-4">@{profile.username}</td>
                        <td className="py-3 px-4 hidden md:table-cell">{profile.name}</td>
                        <td className="py-3 px-4">{profile.followers.toLocaleString()}</td>
                        <td className="py-3 px-4 hidden md:table-cell">{profile.engagement}</td>
                        <td className="py-3 px-4 hidden md:table-cell">{profile.posts}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
              
              {/* Save List Form */}
              <div className="card">
                <h3 className="text-lg font-semibold mb-4">Save Lead List</h3>
                <div className="flex flex-col sm:flex-row gap-4 items-end">
                  <div className="flex-grow">
                    <label htmlFor="listName" className="block mb-2 text-sm font-medium text-gray-300">
                      List Name
                    </label>
                    <input
                      type="text"
                      id="listName"
                      value={listName}
                      onChange={(e) => setListName(e.target.value)}
                      placeholder="e.g. Fitness Influencers - Oct 2023"
                      className="input-field"
                      required
                    />
                  </div>
                  <button
                    type="button"
                    onClick={handleSaveList}
                    className="primary-button whitespace-nowrap"
                    disabled={savingStatus !== 'idle' || !listName.trim()}
                  >
                    {savingStatus === 'saving' ? 'Saving...' : savingStatus === 'saved' ? 'Saved!' : 'Save List'}
                  </button>
                </div>
              </div>
            </div>
          )}
        </div>
      </main>

      <Footer />
    </div>
  );
} 