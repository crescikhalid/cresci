'use client';

import { motion } from 'framer-motion';
import { useEffect, useState } from 'react';
import Link from 'next/link';
import Navigation from '../components/Navigation';
import Footer from '../components/Footer';
import GradientBorderButton from '@/app/components/GradientBorderButton';
import LoadingCheckmark from '@/app/components/LoadingCheckmark';

export default function Success() {
  const [isVisible, setIsVisible] = useState(false);
  
  useEffect(() => {
    const timer = setTimeout(() => {
      setIsVisible(true);
    }, 100);
    
    return () => clearTimeout(timer);
  }, []);

  return (
    <div className="flex flex-col min-h-screen bg-black">
      <Navigation />
      
      <main className="flex-grow">
        <section className="relative min-h-screen flex items-center justify-center overflow-hidden pt-24">
          <div className="container mx-auto px-6">
            <motion.div 
              className="max-w-2xl mx-auto"
              initial={{ opacity: 0, y: 30 }}
              animate={{ opacity: isVisible ? 1 : 0, y: isVisible ? 0 : 30 }}
              transition={{ duration: 0.7 }}
            >
              <div className="bg-gray-900/80 backdrop-blur-md p-8 rounded-xl border border-gray-800 text-center">
                <div className="flex justify-center mb-6">
                  <div className="w-20 h-20 scale-150">
                    <LoadingCheckmark isLoading={false} isSuccess={true} />
                  </div>
                </div>
                
                <h1 className="text-3xl sm:text-4xl font-bold mb-3 text-white">
                  You're in! 🎉
                </h1>
                
                <p className="text-xl text-gray-300 mb-8">
                  Thanks for being an early supporter. You've secured lifetime access at the early bird price.
                </p>
                
                <div className="mb-8">
                  <p className="text-gray-400 mb-6">
                    I'll email you as soon as the beta is ready. In the meantime, check out my progress on Instagram.
                  </p>
                  
                  <Link href="https://instagram.com" className="relative inline-block mb-6">
                    <div className="absolute inset-0 rounded-full animate-pulse bg-gradient-to-r from-purple-500 via-blue-500 to-teal-500 opacity-70 blur-[2px] p-1"></div>
                    <div className="relative z-10 bg-gray-800 px-5 py-3 rounded-full flex items-center space-x-2">
                      <svg 
                        className="w-5 h-5" 
                        fill="white" 
                        xmlns="http://www.w3.org/2000/svg" 
                        viewBox="0 0 448 512"
                      >
                        <path d="M224.1 141c-63.6 0-114.9 51.3-114.9 114.9s51.3 114.9 114.9 114.9S339 319.5 339 255.9 287.7 141 224.1 141zm0 189.6c-41.1 0-74.7-33.5-74.7-74.7s33.5-74.7 74.7-74.7 74.7 33.5 74.7 74.7-33.6 74.7-74.7 74.7zm146.4-194.3c0 14.9-12 26.8-26.8 26.8-14.9 0-26.8-12-26.8-26.8s12-26.8 26.8-26.8 26.8 12 26.8 26.8zm76.1 27.2c-1.7-35.9-9.9-67.7-36.2-93.9-26.2-26.2-58-34.4-93.9-36.2-37-2.1-147.9-2.1-184.9 0-35.8 1.7-67.6 9.9-93.9 36.1s-34.4 58-36.2 93.9c-2.1 37-2.1 147.9 0 184.9 1.7 35.9 9.9 67.7 36.2 93.9s58 34.4 93.9 36.2c37 2.1 147.9 2.1 184.9 0 35.9-1.7 67.7-9.9 93.9-36.2 26.2-26.2 34.4-58 36.2-93.9 2.1-37 2.1-147.8 0-184.8zM398.8 388c-7.8 19.6-22.9 34.7-42.6 42.6-29.5 11.7-99.5 9-132.1 9s-102.7 2.6-132.1-9c-19.6-7.8-34.7-22.9-42.6-42.6-11.7-29.5-9-99.5-9-132.1s-2.6-102.7 9-132.1c7.8-19.6 22.9-34.7 42.6-42.6 29.5-11.7 99.5-9 132.1-9s102.7-2.6 132.1 9c19.6 7.8 34.7 22.9 42.6 42.6 11.7 29.5 9 99.5 9 132.1s2.7 102.7-9 132.1z"/>
                      </svg>
                      <span className="text-white">Follow on Instagram</span>
                    </div>
                  </Link>
                </div>
                
                <Link href="/">
                  <motion.button
                    className="bg-gray-800 text-white font-medium py-3 px-6 rounded-lg transition-all duration-200"
                    whileHover={{ scale: 1.03 }}
                    whileTap={{ scale: 0.97 }}
                  >
                    Back to Home
                  </motion.button>
                </Link>
              </div>
            </motion.div>
          </div>
        </section>
      </main>

      <Footer />
    </div>
  );
} 