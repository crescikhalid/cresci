'use client';

import { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import Navigation from '../components/Navigation';
import Footer from '../components/Footer';
import LoadingCheckmark from '@/app/components/LoadingCheckmark';

export default function Signup() {
  const [email, setEmail] = useState('');
  const [name, setName] = useState('');
  const [status, setStatus] = useState<'idle' | 'loading' | 'success' | 'error'>('idle');
  const [message, setMessage] = useState('');
  const [isVisible, setIsVisible] = useState(false);

  useEffect(() => {
    // Set visible after a small delay for animation purposes
    const timer = setTimeout(() => {
      setIsVisible(true);
    }, 100);
    
    return () => clearTimeout(timer);
  }, []);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setStatus('loading');
    setMessage('');

    try {
      const response = await fetch('/api/signup', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ email, name }),
      });

      const data = await response.json();

      if (!response.ok) {
        throw new Error(data.error || 'Something went wrong');
      }

      setStatus('success');
      setMessage('Thank you for signing up! Redirecting to early access...');
      setEmail('');
      setName('');
      
      // Redirect to early access page after short delay
      setTimeout(() => {
        window.location.href = '/early-access';
      }, 1500);
    } catch (error) {
      setStatus('error');
      setMessage(error instanceof Error ? error.message : 'Failed to sign up');
    }
  };

  return (
    <div className="flex flex-col min-h-screen bg-black">
      <Navigation />
      
      <main className="flex-grow">
        <section className="relative min-h-screen flex items-center justify-center overflow-hidden pt-24">
          <div className="container mx-auto px-6">
            <motion.div 
              className="max-w-md mx-auto"
              initial={{ opacity: 0, y: 30 }}
              animate={{ opacity: isVisible ? 1 : 0, y: isVisible ? 0 : 30 }}
              transition={{ duration: 0.7 }}
            >
              <div className="bg-gray-900/80 backdrop-blur-md p-8 rounded-xl border border-gray-800">
                <h1 className="text-3xl font-bold mb-6 text-white text-center">
                  Get Started
                </h1>
                
                <form onSubmit={handleSubmit} className="space-y-4">
                  <div>
                    <label htmlFor="name" className="block text-sm font-medium text-gray-300 mb-1">Name</label>
                    <input
                      type="text"
                      id="name"
                      value={name}
                      onChange={(e) => setName(e.target.value)}
                      placeholder="Your name"
                      className="w-full px-4 py-3 rounded-lg bg-gray-800 border border-gray-700 text-white placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                      required
                      disabled={status === 'loading'}
                    />
                  </div>
                  <div>
                    <label htmlFor="email" className="block text-sm font-medium text-gray-300 mb-1">Email</label>
                    <input
                      type="email"
                      id="email"
                      value={email}
                      onChange={(e) => setEmail(e.target.value)}
                      placeholder="your@email.com"
                      className="w-full px-4 py-3 rounded-lg bg-gray-800 border border-gray-700 text-white placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                      required
                      disabled={status === 'loading'}
                    />
                  </div>
                  <div className="pt-4">
                    <motion.div
                      className="relative"
                      whileHover={{ scale: 1.03 }}
                      whileTap={{ scale: 0.97 }}
                      transition={{
                        type: "spring",
                        stiffness: 400,
                        damping: 15
                      }}
                    >
                      <div 
                        className="absolute inset-0 rounded-lg opacity-90 bg-gradient-to-r from-purple-500 via-blue-500 to-teal-500"
                        style={{ 
                          backgroundSize: "200% 200%",
                          animation: "gradientAnimation 6s linear infinite"
                        }}
                      />
                      <button
                        type="submit"
                        className="relative w-full py-3 px-6 bg-gray-900 text-white font-medium rounded-lg transition-all duration-200"
                        disabled={status === 'loading'}
                      >
                        <div className="flex items-center justify-center space-x-2">
                          {status === 'loading' && <LoadingCheckmark isLoading={status === 'loading'} />}
                          <span>{status === 'loading' ? 'Signing up...' : 'Sign Up'}</span>
                        </div>
                      </button>
                    </motion.div>
                  </div>
                </form>
                
                {message && (
                  <motion.div 
                    className={`mt-4 text-sm ${status === 'success' ? 'text-green-400' : 'text-red-400'} text-center`}
                    initial={{ opacity: 0, y: 10 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ duration: 0.3 }}
                  >
                    <div className="flex items-center justify-center space-x-2">
                      {status === 'success' && <LoadingCheckmark isLoading={false} isSuccess={true} />}
                      <span>{message}</span>
                    </div>
                  </motion.div>
                )}
              </div>
            </motion.div>
          </div>
        </section>
      </main>

      <Footer />
    </div>
  );
} 