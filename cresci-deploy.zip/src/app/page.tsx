'use client';

import { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import Navigation from './components/Navigation';
import Footer from './components/Footer';
import CubeScene from './components/CubeScene';
import GradientBorderButton from '@/app/components/GradientBorderButton';
import LoadingCheckmark from '@/app/components/LoadingCheckmark';
import LaunchCounter from '@/app/components/LaunchCounter';

export default function Home() {
  const [email, setEmail] = useState('');
  const [name, setName] = useState('');
  const [status, setStatus] = useState<'idle' | 'loading' | 'success' | 'error'>('idle');
  const [message, setMessage] = useState('');
  const [isVisible, setIsVisible] = useState(false);
  const [signupCount, setSignupCount] = useState(37); // Start with 37 signups as a marketing tactic

  useEffect(() => {
    // Set visible after a small delay for animation purposes
    const timer = setTimeout(() => {
      setIsVisible(true);
    }, 100);
    
    // Fetch the current signup count
    fetchSignupCount();
    
    return () => clearTimeout(timer);
  }, []);

  const fetchSignupCount = async () => {
    try {
      const response = await fetch('/api/signup');
      if (response.ok) {
        const data = await response.json();
        // Only update if the actual count is higher than our marketing count
        if (data.count > signupCount) {
          setSignupCount(data.count);
        }
      }
    } catch (error) {
      console.error('Error fetching signup count:', error);
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setStatus('loading');
    setMessage('');

    try {
      const response = await fetch('/api/signup', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ email, name }),
      });

      const data = await response.json();

      if (!response.ok) {
        throw new Error(data.error || 'Something went wrong');
      }

      setStatus('success');
      setMessage('Thank you for signing up! Redirecting to early access...');
      setEmail('');
      setName('');
      
      // Always increment our count by 1 on successful signup
      setSignupCount(prevCount => prevCount + 1);
      
      // Redirect to early access page after short delay
      setTimeout(() => {
        window.location.href = '/early-access';
      }, 1500);
    } catch (error) {
      setStatus('error');
      setMessage(error instanceof Error ? error.message : 'Failed to sign up');
    }
  };

  return (
    <div className="flex flex-col min-h-screen bg-black">
      <Navigation />
      
      <main className="flex-grow">
        {/* Hero Section */}
        <section className="relative min-h-screen flex items-center justify-center overflow-hidden pt-24">
          <div className="container mx-auto px-6">
            <div className="flex flex-col md:flex-row items-center md:items-start md:justify-between">
              {/* Left Content - Text and Form */}
              <motion.div 
                className="md:w-1/2 text-left mb-12 md:mb-0 z-20 relative mt-10"
                initial={{ opacity: 0, y: 30 }}
                animate={{ opacity: isVisible ? 1 : 0, y: isVisible ? 0 : 30 }}
                transition={{ duration: 0.7 }}
              >
                <motion.h1 
                  className="text-3xl sm:text-4xl md:text-5xl font-bold leading-none bg-gradient-to-r from-white via-gray-300 to-white bg-clip-text text-transparent">
                  <span className="block">Effortless Outreach</span>
                  <span className="block">Maximum Results</span>
                </motion.h1>
                
                <motion.p 
                  className="text-lg sm:text-xl text-gray-300 mb-6 mt-1"
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: isVisible ? 1 : 0, y: isVisible ? 0 : 20 }}
                  transition={{ duration: 0.5, delay: 0.4 }}
                >
                  Your all-in-one platform for automating outreach,
scaling client acquisition, and driving revenue.
                </motion.p>
                
                <motion.div 
                  className="flex flex-col sm:flex-row gap-6 mb-8"
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: isVisible ? 1 : 0, y: isVisible ? 0 : 20 }}
                  transition={{ duration: 0.5, delay: 0.6 }}
                >
                  <GradientBorderButton href="/signup" text="Get Started" isActive={true} />
                  <GradientBorderButton href="/learn-more" text="Learn More" isActive={true} />
                </motion.div>
                
                {/* Sign Up Form */}
                <motion.div
                  className="w-full mb-8 mt-8"
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: isVisible ? 1 : 0, y: isVisible ? 0 : 20 }}
                  transition={{ duration: 0.5, delay: 0.8 }}
                >
                  <div className="relative h-[280px] w-full">
                    {/* Floating Gradient Bubbles */}
                    <motion.div 
                      className="absolute top-0 left-4 w-32 h-32 rounded-full bg-gradient-to-r from-purple-500 via-blue-500 to-teal-500 opacity-70 blur-[2px]"
                      animate={{
                        y: [0, -15, 0],
                        x: [0, 5, 0],
                        scale: [1, 1.05, 1],
                      }}
                      transition={{
                        duration: 4,
                        repeat: Infinity,
                        repeatType: "reverse",
                        ease: "easeInOut"
                      }}
                    />
                    <motion.div 
                      className="absolute top-10 right-24 w-24 h-24 rounded-full bg-gradient-to-r from-blue-500 via-teal-500 to-purple-500 opacity-70 blur-[2px]"
                      animate={{
                        y: [0, 15, 0],
                        x: [0, -5, 0],
                        scale: [1, 1.1, 1],
                      }}
                      transition={{
                        duration: 5,
                        repeat: Infinity,
                        repeatType: "reverse",
                        ease: "easeInOut",
                        delay: 0.5
                      }}
                    />
                    <motion.div 
                      className="absolute bottom-0 left-12 w-20 h-20 rounded-full bg-gradient-to-r from-teal-500 via-purple-500 to-blue-500 opacity-70 blur-[2px]"
                      animate={{
                        y: [0, -10, 0],
                        x: [0, 10, 0],
                        scale: [1, 1.08, 1],
                      }}
                      transition={{
                        duration: 4.5,
                        repeat: Infinity,
                        repeatType: "reverse",
                        ease: "easeInOut",
                        delay: 1
                      }}
                    />
                    
                    {/* Signup Form */}
                    <div className="absolute inset-0 flex items-center justify-start">
                      <motion.div 
                        className="bg-gray-900/80 backdrop-blur-md p-6 rounded-xl border border-gray-800 w-full max-w-sm"
                        whileHover={{ boxShadow: "0 15px 30px rgba(75, 85, 99, 0.3)" }}
                      >
                        <h3 className="text-xl font-semibold mb-2 text-white">Join our waitlist</h3>
                        <form onSubmit={handleSubmit} className="space-y-3">
                          <div>
                            <label htmlFor="name" className="sr-only">Name</label>
                            <input
                              type="text"
                              id="name"
                              value={name}
                              onChange={(e) => setName(e.target.value)}
                              placeholder="Your name"
                              className="w-full px-4 py-3 rounded-lg bg-gray-800 border border-gray-700 text-white placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                              required
                              disabled={status === 'loading'}
                            />
                          </div>
                          <div>
                            <label htmlFor="email" className="sr-only">Email</label>
                            <input
                              type="email"
                              id="email"
                              value={email}
                              onChange={(e) => setEmail(e.target.value)}
                              placeholder="your@email.com"
                              className="w-full px-4 py-3 rounded-lg bg-gray-800 border border-gray-700 text-white placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                              required
                              disabled={status === 'loading'}
                            />
                          </div>
                          <div className="relative">
                            <motion.div
                              className="relative"
                              whileHover={{ scale: 1.03 }}
                              whileTap={{ scale: 0.97 }}
                              transition={{
                                type: "spring",
                                stiffness: 400,
                                damping: 15
                              }}
                            >
                              <div 
                                className="absolute inset-0 rounded-lg opacity-90 bg-gradient-to-r from-purple-500 via-blue-500 to-teal-500"
                                style={{ 
                                  backgroundSize: "200% 200%",
                                  animation: "gradientAnimation 6s linear infinite"
                                }}
                              />
                              <button
                                type="submit"
                                className="relative w-full py-3 px-6 bg-gray-900 text-white font-medium rounded-lg transition-all duration-200"
                                disabled={status === 'loading'}
                              >
                                <div className="flex items-center justify-center space-x-2">
                                  {status === 'loading' && <LoadingCheckmark isLoading={status === 'loading'} />}
                                  <span>{status === 'loading' ? 'Signing up...' : 'Join Waitlist'}</span>
                                </div>
                              </button>
                            </motion.div>
                          </div>
                        </form>
                        {message && (
                          <motion.div 
                            className={`mt-4 text-sm ${status === 'success' ? 'text-green-400' : 'text-red-400'}`}
                            initial={{ opacity: 0, y: 10 }}
                            animate={{ opacity: 1, y: 0 }}
                            transition={{ duration: 0.3 }}
                          >
                            <div className="flex items-center justify-center space-x-2">
                              {status === 'success' && <LoadingCheckmark isLoading={false} isSuccess={true} />}
                              <span>{message}</span>
                            </div>
                          </motion.div>
                        )}
                      </motion.div>
                    </div>
                  </div>
                </motion.div>
              </motion.div>
              
              {/* Right Content - 3D Cube */}
              <motion.div 
                className="md:w-1/2 z-0 relative md:pl-12"
                initial={{ opacity: 0, scale: 0.8 }}
                animate={{ opacity: isVisible ? 1 : 0, scale: isVisible ? 1 : 0.8 }}
                transition={{ duration: 0.7, delay: 0.3 }}
              >
                <div className="w-full h-[700px] flex items-center justify-end" style={{ 
                  minHeight: '700px', 
                  overflow: 'visible', 
                  backgroundColor: 'transparent',
                  position: 'relative',
                  zIndex: 0
                }}>
                  <div className="w-full h-full" style={{ 
                    position: 'relative', 
                    overflow: 'visible', 
                    backgroundColor: 'transparent'
                  }}>
                    <CubeScene />
                  </div>
                </div>
              </motion.div>
            </div>
          </div>
        </section>

        {/* Launch Counter Section */}
        <section className="py-8 bg-black relative z-10">
          <div className="container mx-auto px-4">
            <div className="max-w-md mx-auto">
              <LaunchCounter 
                signupCount={signupCount} 
                targetCount={100} 
                launchDate={new Date(Date.now() + 14 * 24 * 60 * 60 * 1000)} 
              />
            </div>
          </div>
        </section>

        {/* Features Section */}
        <section id="features" className="pt-12 pb-20 bg-black">
          <div className="container mx-auto px-4">
            <div className="max-w-4xl mx-auto">
              <motion.h2 
                className="text-4xl sm:text-5xl font-bold mb-2 text-center text-white"
                initial={{ opacity: 0, y: 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.6 }}
              >
                Features that drive growth
              </motion.h2>
              
              <motion.p 
                className="text-lg text-gray-300 mb-16 text-center max-w-2xl mx-auto"
                initial={{ opacity: 0, y: 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.6, delay: 0.2 }}
              >
                Our platform streamlines every step of growth operating, letting you focus on building relationships that scale your business.
              </motion.p>
              
              <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                <motion.div 
                  className="bg-gray-900 rounded-lg p-6 shadow-lg border border-gray-800 h-full"
                  initial={{ opacity: 0, y: 30 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.5, delay: 0.1 }}
                  whileHover={{ 
                    y: -10, 
                    boxShadow: "0 15px 30px rgba(75, 85, 99, 0.3)",
                    transition: { duration: 0.2 }
                  }}
                >
                  <h3 className="text-xl font-semibold mb-2 text-white">Automated Outreach</h3>
                  <p className="text-gray-400">Create personalized outreach campaigns that scale. Reach more prospects with less effort and track every interaction.</p>
                </motion.div>
                
                <motion.div 
                  className="bg-gray-900 rounded-lg p-6 shadow-lg border border-gray-800 h-full"
                  initial={{ opacity: 0, y: 30 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.5, delay: 0.2 }}
                  whileHover={{ 
                    y: -10, 
                    boxShadow: "0 15px 30px rgba(75, 85, 99, 0.3)",
                    transition: { duration: 0.2 }
                  }}
                >
                  <h3 className="text-xl font-semibold mb-2 text-white">Lead Management</h3>
                  <p className="text-gray-400">Organize leads into targeted lists, add custom notes, track outreach status, and manage your entire client pipeline in one place.</p>
                </motion.div>
                
                <motion.div 
                  className="bg-gray-900 rounded-lg p-6 shadow-lg border border-gray-800 h-full"
                  initial={{ opacity: 0, y: 30 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.5, delay: 0.3 }}
                  whileHover={{ 
                    y: -10, 
                    boxShadow: "0 15px 30px rgba(75, 85, 99, 0.3)",
                    transition: { duration: 0.2 }
                  }}
                >
                  <h3 className="text-xl font-semibold mb-2 text-white">AI-Powered Templates</h3>
                  <p className="text-gray-400">Create message templates with dynamic personalization variables. Leverage AI to optimize messaging and boost response rates.</p>
                </motion.div>
                
                <motion.div 
                  className="bg-gray-900 rounded-lg p-6 shadow-lg border border-gray-800 h-full"
                  initial={{ opacity: 0, y: 30 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.5, delay: 0.4 }}
                  whileHover={{ 
                    y: -10, 
                    boxShadow: "0 15px 30px rgba(75, 85, 99, 0.3)",
                    transition: { duration: 0.2 }
                  }}
                >
                  <h3 className="text-xl font-semibold mb-2 text-white">Analytics & Insights</h3>
                  <p className="text-gray-400">Track open rates, response rates, and conversion metrics. Optimize your outreach strategy with data-driven insights.</p>
                </motion.div>
              </div>
            </div>
          </div>
        </section>
        
        {/* Work in Progress Section */}
        <section className="py-16 bg-gray-900">
          <div className="container mx-auto px-4">
            <motion.div 
              className="max-w-6xl mx-auto"
              initial={{ opacity: 0 }}
              whileInView={{ opacity: 1 }}
              viewport={{ once: true }}
              transition={{ duration: 0.7 }}
            >
              <div className="flex flex-col md:flex-row items-center gap-12">
                <div className="md:w-2/5 text-left mb-12 md:mb-0 md:pr-4 z-10">
                  <h2 className="text-3xl font-bold mb-4 text-white">
                    <span className="text-white opacity-50">Coming Soon:</span> <br/>
                    <span className="text-white">Growth Operating Platform</span>
                  </h2>
                  <p className="text-gray-400 mb-8 text-lg">
                    We're building powerful tools to help you automate your outreach, manage your leads, and scale your business. Join our waitlist to be the first to know when we launch.
                  </p>
                  <div className="flex gap-4">
                    <span className="px-3 py-1 bg-blue-900/30 text-blue-400 rounded-full text-sm">In Development</span>
                    <span className="px-3 py-1 bg-gray-800 text-gray-400 rounded-full text-sm">Launch: 100 signups</span>
                  </div>
                </div>
                <div className="md:w-3/5 text-left mb-12 md:mb-0 md:pr-4 z-10">
                  <div className="bg-gray-800 p-8 rounded-xl border border-gray-700 shadow-lg">
                    <div className="text-left mb-6">
                      <div className="flex items-center space-x-2 mb-3">
                        {/* macOS window controls: close, minimize, maximize */}
                        <div className="h-3 w-3 rounded-full bg-[#FF5F56] hover:bg-[#FF5F56]/90 transition-colors"></div>
                        <div className="h-3 w-3 rounded-full bg-[#FFBD2E] hover:bg-[#FFBD2E]/90 transition-colors"></div>
                        <div className="h-3 w-3 rounded-full bg-[#27C93F] hover:bg-[#27C93F]/90 transition-colors"></div>
                      </div>
                      <p className="text-gray-400 text-sm mb-2">Message Template Builder</p>
                    </div>
                    <div className="border border-gray-700 rounded-lg p-6 bg-gray-900/70">
                      <p className="text-sm text-gray-300 font-mono">
                        Hey {"{{name}}"},<br/><br/>
                        I love your content about {"{{topic}}"}! Your {"{{recent_post}}"} really caught my attention.<br/><br/>
                        I'm reaching out because {"{{brand}}"} is looking for creators like you for our upcoming campaign.<br/><br/>
                        Would you be interested in a collaboration?<br/><br/>
                        {"{{signature}}"}
                      </p>
                    </div>
                    <div className="mt-6 flex gap-3">
                      <span className="px-4 py-2 bg-gray-700 text-white rounded-md text-xs">Name</span>
                      <span className="px-4 py-2 bg-gray-700 text-white rounded-md text-xs">Topic</span>
                      <span className="px-4 py-2 bg-gray-700 text-white rounded-md text-xs">+4 more</span>
                    </div>
                  </div>
                </div>
              </div>
            </motion.div>
          </div>
        </section>
        
        {/* CTA Section */}
        <section className="py-20 bg-black border-t border-gray-800">
          <div className="container mx-auto px-4">
            <motion.div 
              className="max-w-3xl mx-auto text-center"
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.7 }}
            >
              <h2 className="text-4xl sm:text-5xl font-bold mb-2 text-white">
                Ready to scale your business?
              </h2>
              <p className="text-lg text-gray-300 mb-10">
                Join thousands of businesses that are automating their growth operations and driving more revenue.
              </p>
              <GradientBorderButton href="/signup" text="Get Started" isActive={true} />
            </motion.div>
        </div>
        </section>
      </main>

      <Footer />
    </div>
  );
}
