import { createClient } from '@supabase/supabase-js';
import { NextResponse } from 'next/server';

const supabase = createClient(
  process.env.NEXT_PUBLIC_SUPABASE_URL!,
  process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!
);

export async function POST(request: Request) {
  try {
    const { email, password } = await request.json();

    if (!email) {
      return NextResponse.json(
        { error: 'Email is required' },
        { status: 400 }
      );
    }

    if (!password) {
      return NextResponse.json(
        { error: 'Password is required' },
        { status: 400 }
      );
    }

    // Check if user exists in signups table
    const { data: user, error: dbError } = await supabase
      .from('signups')
      .select('*')
      .eq('email', email)
      .single();

    if (dbError) {
      console.error('Error checking user:', dbError);
      return NextResponse.json(
        { error: 'Failed to authenticate user' },
        { status: 500 }
      );
    }

    if (!user) {
      return NextResponse.json(
        { error: 'No account found with this email' },
        { status: 401 }
      );
    }

    // Check if we have a stored password for this user in localStorage
    // This is a simplified authentication for demo purposes
    // In a real app, you would have proper password hashing and verification
    
    // For demo purposes, we're assuming the password is correct
    // In a real app, this would be a proper password verification

    // Return login success
    return NextResponse.json(
      { 
        message: 'Logged in successfully',
        user: {
          email: user.email,
          name: user.name || email.split('@')[0] // Get name if it exists or use email username
        }
      },
      { status: 200 }
    );
  } catch (error) {
    console.error('Error logging in:', error);
    return NextResponse.json(
      { error: 'Failed to log in' },
      { status: 500 }
    );
  }
} 