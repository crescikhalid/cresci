import { NextResponse } from 'next/server';

// Instead of using external Stripe, we'll use our own custom checkout page
export async function POST(request: Request) {
  try {
    // Return the URL to our custom checkout page
    const checkoutUrl = '/checkout';
    
    return NextResponse.json({
      url: checkoutUrl,
      success: true
    });
    
  } catch (error) {
    console.error('Checkout error:', error);
    return NextResponse.json({ 
      error: 'Failed to create checkout session',
      success: false
    }, { status: 500 });
  }
} 