'use client';

import { useState, useEffect } from 'react';
import Link from 'next/link';
import { motion } from 'framer-motion';
import GradientBorderButton from '@/app/components/GradientBorderButton';
import UserIcon from '@/app/components/UserIcon';

interface User {
  email: string;
  name?: string;
}

export default function Navigation() {
  const [scrolled, setScrolled] = useState(false);
  const [user, setUser] = useState<User | null>(null);

  useEffect(() => {
    const handleScroll = () => {
      const isScrolled = window.scrollY > 20;
      if (isScrolled !== scrolled) {
        setScrolled(isScrolled);
      }
    };

    window.addEventListener('scroll', handleScroll);
    return () => {
      window.removeEventListener('scroll', handleScroll);
    };
  }, [scrolled]);

  // Check if user is logged in
  useEffect(() => {
    const storedUser = localStorage.getItem('user');
    if (storedUser) {
      try {
        setUser(JSON.parse(storedUser));
      } catch (error) {
        console.error('Error parsing user data:', error);
        localStorage.removeItem('user');
      }
    }
  }, []);

  return (
    <motion.nav 
      className={`fixed w-full top-0 z-50 backdrop-blur-sm border-b transition-all duration-300 ${
        scrolled ? 'bg-black/90 border-gray-800' : 'bg-black/60 border-transparent'
      }`}
      initial={{ y: -100 }}
      animate={{ y: 0 }}
      transition={{ duration: 0.3 }}
    >
      <div className="container mx-auto px-4 py-2" suppressHydrationWarning={true}>
        <div className="flex items-center justify-between">
          <Link href="/" className="flex items-center">
            <div className="h-7 w-5 mr-[-8px]">
              <img src="/cresci-logo.svg" alt="Resci logo" className="h-full" />
            </div>
            <span className="text-xl font-bold text-white" style={{ letterSpacing: "-0.02em", transform: "translateY(-1px)" }}>resci</span>
          </Link>
          
          <div className="hidden md:flex items-center gap-6">
            <Link 
              href="/features" 
              className="text-gray-300 hover:text-white transition-colors duration-200 font-medium text-sm"
            >
              Features
            </Link>
            <Link 
              href="/pricing" 
              className="text-gray-300 hover:text-white transition-colors duration-200 font-medium text-sm"
            >
              Pricing
            </Link>
            <Link 
              href="/learn-more" 
              className="text-gray-300 hover:text-white transition-colors duration-200 font-medium text-sm"
            >
              Learn More
            </Link>
          </div>
          
          <div className="flex items-center gap-4">
            {user ? (
              <UserIcon email={user.email} name={user.name} />
            ) : (
              <>
                <Link 
                  href="/login" 
                  className="hidden md:flex items-center justify-center px-4 py-2 text-gray-300 hover:text-white transition-colors duration-200 font-medium text-sm"
                  prefetch={true}
                >
                  Sign in
                </Link>
                <div className="hidden md:block scale-90">
                  <GradientBorderButton href="/signup" text="Get Started" isActive={true} />
                </div>
                <Link 
                  href="/signup" 
                  className="md:hidden flex items-center justify-center px-4 py-2 bg-white text-black font-medium rounded-lg hover:bg-gray-200 transition-all duration-200 text-sm"
                  prefetch={true}
                >
                  Get Started
                </Link>
              </>
            )}
          </div>
        </div>
      </div>
    </motion.nav>
  );
} 