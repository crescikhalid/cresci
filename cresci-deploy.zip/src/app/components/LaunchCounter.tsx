'use client';

import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';

interface LaunchCounterProps {
  signupCount?: number; // Current number of signups
  targetCount?: number; // Target number of signups to start countdown
  launchDate?: Date; // Launch date for countdown
}

const LaunchCounter: React.FC<LaunchCounterProps> = ({ 
  signupCount = 0, // Start with 0 signups
  targetCount = 100, // Countdown starts when this is reached
  launchDate = new Date(Date.now() + 7 * 24 * 60 * 60 * 1000) // Default: 7 days from now
}) => {
  const [timeLeft, setTimeLeft] = useState({
    days: 0,
    hours: 0,
    minutes: 0,
    seconds: 0
  });
  
  const percentage = Math.min(Math.floor((signupCount / targetCount) * 100), 100);
  const hasReachedTarget = signupCount >= targetCount;
  
  useEffect(() => {
    if (!hasReachedTarget) return;
    
    // Calculate time left only if we've reached the target count
    const timer = setInterval(() => {
      const now = new Date();
      const difference = launchDate.getTime() - now.getTime();
      
      if (difference <= 0) {
        clearInterval(timer);
        setTimeLeft({ days: 0, hours: 0, minutes: 0, seconds: 0 });
        return;
      }
      
      const days = Math.floor(difference / (1000 * 60 * 60 * 24));
      const hours = Math.floor((difference % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
      const minutes = Math.floor((difference % (1000 * 60 * 60)) / (1000 * 60));
      const seconds = Math.floor((difference % (1000 * 60)) / 1000);
      
      setTimeLeft({ days, hours, minutes, seconds });
    }, 1000);
    
    return () => clearInterval(timer);
  }, [hasReachedTarget, launchDate]);
  
  return (
    <motion.div 
      className="relative rounded-xl bg-gray-900 border border-gray-800 shadow-lg"
      initial={{ opacity: 0, y: 30 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5 }}
      whileHover={{ 
        y: -10, 
        boxShadow: "0 15px 30px rgba(75, 85, 99, 0.3)",
        transition: { duration: 0.2 }
      }}
    >
      {/* Card content */}
      <div className="relative z-10 p-6">
        <div className="text-center">
          <h3 className="text-xl font-bold mb-4 text-white bg-clip-text text-transparent bg-gradient-to-r from-purple-400 via-blue-500 to-teal-400">
            {hasReachedTarget ? "Launching Soon!" : "Launch Progress"}
          </h3>
          
          {!hasReachedTarget && (
            <>
              <div className="mb-4 flex justify-center items-center gap-2">
                <span className="text-xl font-bold text-blue-400">{signupCount}</span>
                <span className="text-gray-400">of</span>
                <span className="text-xl font-bold text-gray-300">{targetCount}</span>
                <span className="text-gray-400 ml-1">signups</span>
              </div>
              
              <div className="w-full h-2 bg-gray-800 rounded-full mb-4 relative overflow-hidden">
                <div className="absolute inset-0 rounded-full">
                  <motion.div 
                    className="h-full rounded-full"
                    style={{ width: `${percentage}%` }}
                    animate={{
                      background: [
                        'linear-gradient(90deg, #8B5CF6, #3B82F6, #14B8A6)',
                        'linear-gradient(90deg, #3B82F6, #14B8A6, #8B5CF6)',
                        'linear-gradient(90deg, #14B8A6, #8B5CF6, #3B82F6)',
                        'linear-gradient(90deg, #8B5CF6, #3B82F6, #14B8A6)',
                      ],
                    }}
                    transition={{ 
                      duration: 8, 
                      repeat: Infinity, 
                      repeatType: "loop",
                    }}
                  />
                </div>
              </div>
              
              <p className="text-sm text-gray-400 font-medium">
                {percentage}% complete - {targetCount - signupCount} more to go!
              </p>
            </>
          )}
          
          {hasReachedTarget && (
            <div className="grid grid-cols-4 gap-4 mt-4">
              {[
                { value: timeLeft.days, label: "Days" },
                { value: timeLeft.hours, label: "Hours" },
                { value: timeLeft.minutes, label: "Minutes" },
                { value: timeLeft.seconds, label: "Seconds" }
              ].map((item, index) => (
                <div key={index} className="flex flex-col items-center">
                  <div className="w-16 h-16 rounded-lg flex items-center justify-center bg-gray-800/60 backdrop-blur-sm relative overflow-hidden">
                    <div className="absolute inset-0 opacity-20">
                      <motion.div
                        className="absolute inset-0"
                        animate={{
                          background: [
                            'linear-gradient(90deg, #8B5CF6, #3B82F6)',
                            'linear-gradient(180deg, #3B82F6, #8B5CF6)',
                            'linear-gradient(270deg, #8B5CF6, #3B82F6)',
                            'linear-gradient(360deg, #8B5CF6, #3B82F6)',
                          ],
                        }}
                        transition={{ 
                          duration: 4, 
                          repeat: Infinity, 
                          repeatType: "loop",
                        }}
                      />
                    </div>
                    <span className="text-2xl font-bold relative z-10 text-white">{item.value}</span>
                  </div>
                  <span className="text-xs mt-2 text-gray-400 font-medium">{item.label}</span>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
    </motion.div>
  );
};

export default LaunchCounter; 