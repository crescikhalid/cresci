'use client';

import React, { useRef, useMemo } from 'react';
import { useFrame } from '@react-three/fiber';
import { RoundedBox } from '@react-three/drei';
import * as THREE from 'three';

interface SimpleCubeProps {
  position: [number, number, number];
  size: number;
}

export default function SimpleCube({ position, size }: SimpleCubeProps) {
  // Memoize size to prevent changes on re-renders
  const fixedSize = useMemo(() => size, [size]);
  const cubeRef = useRef<THREE.Mesh>(null!);
  
  useFrame(() => {
    // Normal rotation animation
    cubeRef.current.rotation.y += 0.007;
    cubeRef.current.rotation.x += 0.003;
  });

  return (
    <RoundedBox 
      ref={cubeRef}
      args={[fixedSize * 0.8, fixedSize * 0.8, fixedSize * 0.8]}
      radius={(fixedSize * 0.8) * 0.1}
      smoothness={4}
      position={position}
      castShadow
      receiveShadow
    >
      <meshStandardMaterial 
        color="#ffffff"
        emissive="#ffffff"
        emissiveIntensity={0.1}
        roughness={0.05}
        metalness={0.1}
        envMapIntensity={1.5}
      />
    </RoundedBox>
  );
} 