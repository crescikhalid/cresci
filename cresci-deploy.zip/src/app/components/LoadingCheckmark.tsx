'use client';

import React from 'react';
import { motion } from 'framer-motion';

interface LoadingCheckmarkProps {
  isLoading: boolean;
  isSuccess?: boolean;
}

export default function LoadingCheckmark({ isLoading, isSuccess = false }: LoadingCheckmarkProps) {
  const circleVariants = {
    hidden: { opacity: 0, scale: 0 },
    visible: { 
      opacity: 1, 
      scale: 1, 
      transition: { 
        duration: 0.5,
        ease: "easeInOut"
      } 
    },
    success: { 
      opacity: 1, 
      scale: 1,
      transition: { 
        duration: 0.3,
        ease: "easeOut",
        type: "spring",
        stiffness: 300,
        damping: 20
      }
    }
  };

  const checkVariants = {
    hidden: { pathLength: 0, opacity: 0 },
    visible: { 
      pathLength: isSuccess ? 1 : 0.7, 
      opacity: 1, 
      transition: { 
        pathLength: { duration: 0.5, delay: 0.2, ease: "easeInOut" },
        opacity: { duration: 0.3 }
      }
    },
    success: { 
      pathLength: 1, 
      opacity: 1, 
      transition: { 
        duration: 0.5,
        ease: "easeOut",
        type: "spring",
        stiffness: 300,
        damping: 20
      } 
    }
  };
  
  // Don't render anything when not loading or success
  if (!isLoading && !isSuccess) {
    return null;
  }

  return (
    <div className="flex justify-center items-center">
      <motion.div
        className="w-5 h-5 relative"
        initial="hidden"
        animate={isLoading ? "visible" : isSuccess ? "success" : "hidden"}
      >
        <motion.svg
          xmlns="http://www.w3.org/2000/svg"
          width="20"
          height="20"
          viewBox="0 0 24 24"
          variants={circleVariants}
          className="absolute"
        >
          <motion.circle
            cx="12"
            cy="12"
            r="10"
            fill="none"
            stroke="#22c55e" // Green-500
            strokeWidth="2.5"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
          />
        </motion.svg>
        
        <motion.svg
          xmlns="http://www.w3.org/2000/svg"
          width="20"
          height="20"
          viewBox="0 0 24 24"
          className="absolute"
        >
          <motion.path
            d="M6,12 L10,16 L18,8"
            fill="none"
            stroke="#22c55e" // Green-500
            strokeWidth="2.5"
            strokeLinecap="round"
            strokeLinejoin="round"
            variants={checkVariants}
          />
        </motion.svg>
      </motion.div>
    </div>
  );
} 