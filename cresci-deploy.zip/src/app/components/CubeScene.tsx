'use client';

import React, { Suspense, useEffect, useState, useRef } from 'react';
import { Canvas, useThree, useFrame } from '@react-three/fiber';
import { OrbitControls, Environment } from '@react-three/drei';
import { motion } from 'framer-motion';
import * as THREE from 'three';
import SimpleCube from './SimpleCube';

// Camera controller to maintain consistent position
function CameraController() {
  const { camera } = useThree();
  
  useEffect(() => {
    // Set fixed camera position
    camera.position.set(2, 0, 12);
    camera.lookAt(2, 0, 0);
    
    // Cleanup function in case component unmounts
    return () => {};
  }, [camera]);
  
  return null;
}

export default function CubeScene() {
  const [isHovered, setIsHovered] = useState(false);
  
  const labelStyle = "text-gray-300 text-xs bg-gray-900/70 px-2 py-1 rounded";
  
  return (
    <div style={{ 
      width: "150%", 
      height: "150%", 
      position: "absolute", 
      top: "-25%", 
      left: "-25%", 
      overflow: "visible",
      pointerEvents: "auto"
    }}>
      {/* "Spin me" label */}
      <motion.div 
        className="absolute"
        style={{ 
          left: "50%", 
          top: "50%", 
          zIndex: 10,
          transform: "translate(-110%, -50%)",
          opacity: isHovered ? 0 : 0.8,
          pointerEvents: "none"
        }}
        animate={{ 
          opacity: isHovered ? 0 : 0.8
        }}
        transition={{ duration: 0.3 }}
      >
        <div className="flex items-center">
          <svg width="20" height="14" viewBox="0 0 30 16" fill="none" xmlns="http://www.w3.org/2000/svg">
            <path d="M30 8L2 8M2 8L9 1M2 8L9 15" stroke="#999999" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
          </svg>
          <span className={labelStyle}>spin me</span>
        </div>
      </motion.div>
      
      {/* Canvas with 3D cube */}
      <Canvas 
        dpr={[1, 1.5]} 
        shadows 
        camera={{ position: [2, 0, 12], fov: 30 }}
        style={{ 
          width: "100%", 
          height: "100%", 
          position: "absolute", 
          top: 0, 
          left: 0, 
          overflow: "visible",
          zIndex: 1
        }} 
        frameloop="always" 
        resize={{ scroll: false }}
        onPointerOver={() => setIsHovered(true)}
        onPointerOut={() => setIsHovered(false)}
      >
        <Suspense fallback={null}>
          <CameraController />
          
          <ambientLight intensity={0.5} />
          
          {/* Main spotlight from top right */}
          <spotLight
            position={[10, 10, 10]}
            angle={0.3}
            penumbra={1}
            intensity={1}
            distance={50}
            castShadow
          />
          
          {/* Fill light from bottom left to create contrast */}
          <pointLight position={[-5, -5, 5]} intensity={0.3} />
          
          {/* Using SimpleCube with rounded edges */}
          <SimpleCube position={[2, 0, 0]} size={2.5} />
          
          {/* Environment for reflections */}
          <Environment preset="studio" />
          
          <OrbitControls
            enableZoom={false}
            enablePan={false}
            autoRotate={true}
            autoRotateSpeed={0.5}
            minPolarAngle={Math.PI / 8}
            maxPolarAngle={Math.PI * 7 / 8}
            minDistance={9}
            maxDistance={15}
            rotateSpeed={0.4}
            target={[2, 0, 0]}
          />
        </Suspense>
      </Canvas>
    </div>
  );
} 