'use client';

import { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import Link from 'next/link';
import Navigation from '../components/Navigation';
import Footer from '../components/Footer';

export default function Checkout() {
  const [isProcessing, setIsProcessing] = useState(false);
  const [cardNumber, setCardNumber] = useState('');
  const [expDate, setExpDate] = useState('');
  const [cvc, setCvc] = useState('');
  const [name, setName] = useState('');
  const [isVisible, setIsVisible] = useState(false);
  
  // Format card number as user types (add spaces every 4 digits)
  const handleCardNumberChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const value = e.target.value.replace(/\s/g, '').replace(/\D/g, '');
    const formatted = value.replace(/(.{4})/g, '$1 ').trim();
    setCardNumber(formatted);
  };
  
  // Format expiration date as MM/YY
  const handleExpDateChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const value = e.target.value.replace(/\D/g, '');
    if (value.length <= 2) {
      setExpDate(value);
    } else {
      setExpDate(`${value.slice(0, 2)}/${value.slice(2, 4)}`);
    }
  };
  
  // Handle form submission
  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setIsProcessing(true);
    
    // Simulate payment processing
    setTimeout(() => {
      // Redirect to success page
      window.location.href = '/success';
    }, 2000);
  };
  
  // Set visible after a small delay for animation
  useEffect(() => {
    const timer = setTimeout(() => {
      setIsVisible(true);
    }, 100);
    
    return () => clearTimeout(timer);
  }, []);

  return (
    <div className="flex flex-col min-h-screen bg-black">
      <Navigation />
      
      <main className="flex-grow">
        <section className="relative min-h-screen flex items-center justify-center overflow-hidden pt-24">
          <div className="container mx-auto px-6">
            <motion.div 
              className="max-w-md mx-auto"
              initial={{ opacity: 0, y: 30 }}
              animate={{ opacity: isVisible ? 1 : 0, y: isVisible ? 0 : 30 }}
              transition={{ duration: 0.7 }}
            >
              <div className="bg-gray-900/80 backdrop-blur-md p-8 rounded-xl border border-gray-800">
                <div className="flex justify-between items-center mb-6">
                  <h1 className="text-2xl font-bold text-white">Checkout</h1>
                  <div className="text-xl font-bold text-white">$10.00</div>
                </div>
                
                <div className="mb-8">
                  <div className="flex justify-between mb-2">
                    <span className="text-gray-300 text-sm">Early Access Lifetime Deal</span>
                    <span className="text-gray-300 text-sm">$10.00</span>
                  </div>
                  <div className="border-t border-gray-800 pt-2 flex justify-between">
                    <span className="font-medium text-white">Total</span>
                    <span className="font-medium text-white">$10.00</span>
                  </div>
                </div>
                
                <form onSubmit={handleSubmit} className="space-y-4">
                  <div>
                    <label htmlFor="name" className="block text-sm font-medium text-gray-300 mb-1">Cardholder Name</label>
                    <input
                      type="text"
                      id="name"
                      value={name}
                      onChange={(e) => setName(e.target.value)}
                      className="w-full px-4 py-3 rounded-lg bg-gray-800 border border-gray-700 text-white placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                      placeholder="John Doe"
                      required
                      disabled={isProcessing}
                    />
                  </div>
                  
                  <div>
                    <label htmlFor="cardNumber" className="block text-sm font-medium text-gray-300 mb-1">Card Number</label>
                    <input
                      type="text"
                      id="cardNumber"
                      value={cardNumber}
                      onChange={handleCardNumberChange}
                      className="w-full px-4 py-3 rounded-lg bg-gray-800 border border-gray-700 text-white placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                      placeholder="4242 4242 4242 4242"
                      maxLength={19}
                      required
                      disabled={isProcessing}
                    />
                  </div>
                  
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <label htmlFor="expiry" className="block text-sm font-medium text-gray-300 mb-1">Expiration</label>
                      <input
                        type="text"
                        id="expiry"
                        value={expDate}
                        onChange={handleExpDateChange}
                        className="w-full px-4 py-3 rounded-lg bg-gray-800 border border-gray-700 text-white placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                        placeholder="MM/YY"
                        maxLength={5}
                        required
                        disabled={isProcessing}
                      />
                    </div>
                    <div>
                      <label htmlFor="cvc" className="block text-sm font-medium text-gray-300 mb-1">CVC</label>
                      <input
                        type="text"
                        id="cvc"
                        value={cvc}
                        onChange={(e) => setCvc(e.target.value.replace(/\D/g, '').slice(0, 3))}
                        className="w-full px-4 py-3 rounded-lg bg-gray-800 border border-gray-700 text-white placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                        placeholder="123"
                        maxLength={3}
                        required
                        disabled={isProcessing}
                      />
                    </div>
                  </div>
                  
                  <div className="pt-4">
                    <motion.div
                      className="relative overflow-hidden rounded-lg"
                      whileHover={{ scale: 1.03 }}
                      whileTap={{ scale: 0.97 }}
                      transition={{
                        type: "spring",
                        stiffness: 400,
                        damping: 15
                      }}
                    >
                      <div className="absolute inset-0 rounded-lg opacity-90 bg-gradient-to-r from-purple-500 via-blue-500 to-teal-500" 
                        style={{ 
                          backgroundSize: "200% 200%",
                          animation: "gradientAnimation 6s linear infinite"
                        }}
                      />
                      <div className="relative m-[1.5px] rounded-lg overflow-hidden">
                        <button
                          type="submit"
                          className="w-full py-3 px-6 bg-gray-900 text-white font-medium rounded-lg transition-all duration-200"
                          disabled={isProcessing}
                        >
                          {isProcessing ? (
                            <div className="flex items-center justify-center space-x-2">
                              <svg className="animate-spin h-5 w-5 mr-2 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                                <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                                <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                              </svg>
                              <span>Processing...</span>
                            </div>
                          ) : (
                            <span>Pay $10.00</span>
                          )}
                        </button>
                      </div>
                    </motion.div>
                  </div>
                  
                  <div className="mt-4 text-xs text-gray-400 text-center">
                    <p>This is a demo checkout. No real payment will be processed.</p>
                    <p className="mt-1">Use any values for the form fields.</p>
                  </div>
                </form>
                
                <div className="mt-6 text-center">
                  <Link href="/early-access" className="text-blue-400 hover:text-blue-300 text-sm">
                    Cancel and return to previous page
                  </Link>
                </div>
              </div>
              
              <div className="mt-4 text-center flex items-center justify-center">
                <svg className="h-5 w-5 text-gray-500" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 15v2m-6 4h12a2 2 0 002-2v-6a2 2 0 00-2-2H6a2 2 0 00-2 2v6a2 2 0 002 2zm10-10V7a4 4 0 00-8 0v4h8z" />
                </svg>
                <span className="ml-2 text-sm text-gray-500">Secure checkout</span>
              </div>
            </motion.div>
          </div>
        </section>
      </main>

      <Footer />
    </div>
  );
} 