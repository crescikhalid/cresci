'use client';

import { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import Navigation from '../components/Navigation';
import Footer from '../components/Footer';
import GradientBorderButton from '@/app/components/GradientBorderButton';

export default function FeaturesPage() {
  const [isVisible, setIsVisible] = useState(false);

  useEffect(() => {
    // Set visible after a small delay for animation purposes
    const timer = setTimeout(() => {
      setIsVisible(true);
    }, 100);
    
    return () => clearTimeout(timer);
  }, []);

  // Define feature items
  const features = [
    {
      title: "Automated Outreach Campaigns",
      description: "Create personalized outreach sequences that automatically adapt based on prospect behavior. Send follow-ups, schedule meetings, and track responses without manual intervention.",
      icon: "📱",
      delay: 0.1
    },
    {
      title: "AI-Powered Lead Generation",
      description: "Leverage machine learning to identify and prioritize your highest-value prospects. Our AI analyzes engagement patterns to help you focus on leads most likely to convert.",
      icon: "🤖",
      delay: 0.2
    },
    {
      title: "Custom Message Templates",
      description: "Build hyper-personalized message templates with dynamic variables that automatically populate based on each prospect's profile data, creating authentic-feeling outreach at scale.",
      icon: "💬",
      delay: 0.3
    },
    {
      title: "Advanced Analytics Dashboard",
      description: "Track campaign performance with real-time metrics on open rates, response rates, and conversion rates. Optimize your messaging based on data-driven insights.",
      icon: "📊",
      delay: 0.4
    },
    {
      title: "Multi-Channel Campaigns",
      description: "Reach prospects across multiple platforms including email, LinkedIn, Twitter, and more with seamless integration. Ensure your message gets seen wherever your audience engages.",
      icon: "🌐",
      delay: 0.5
    },
    {
      title: "Lead & Relationship Management",
      description: "Organize prospects into custom lists, add private notes, and track communication history. Never lose track of important relationship details again.",
      icon: "👥",
      delay: 0.6
    }
  ];

  return (
    <div className="flex flex-col min-h-screen bg-black">
      <Navigation />
      
      <main className="flex-grow">
        {/* Hero Section */}
        <section className="pt-32 pb-16">
          <div className="container mx-auto px-4">
            <motion.div
              className="max-w-4xl mx-auto text-center"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: isVisible ? 1 : 0, y: isVisible ? 0 : 20 }}
              transition={{ duration: 0.7 }}
            >
              <h1 className="text-5xl font-bold mb-6 bg-gradient-to-r from-white via-gray-300 to-white bg-clip-text text-transparent">
                Features & Capabilities
              </h1>
              <p className="text-xl text-gray-300 mb-10 max-w-3xl mx-auto">
                Explore the powerful tools that will transform your outreach efforts and grow your business.
              </p>
            </motion.div>
          </div>
        </section>

        {/* Features Grid */}
        <section className="py-16">
          <div className="container mx-auto px-4">
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8 max-w-6xl mx-auto">
              {features.map((feature, index) => (
                <motion.div
                  key={index}
                  className="bg-gray-900 rounded-lg p-6 border border-gray-800 h-full"
                  initial={{ opacity: 0, y: 30 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.5, delay: feature.delay }}
                  whileHover={{ 
                    y: -10, 
                    boxShadow: "0 15px 30px rgba(75, 85, 99, 0.3)",
                    transition: { duration: 0.2 }
                  }}
                >
                  <div className="text-3xl mb-4">{feature.icon}</div>
                  <h3 className="text-xl font-semibold mb-3 text-white">{feature.title}</h3>
                  <p className="text-gray-400">{feature.description}</p>
                </motion.div>
              ))}
            </div>
          </div>
        </section>
        
        {/* Work in Progress Section */}
        <section className="py-16 bg-gray-900">
          <div className="container mx-auto px-4">
            <motion.div 
              className="max-w-4xl mx-auto"
              initial={{ opacity: 0 }}
              whileInView={{ opacity: 1 }}
              viewport={{ once: true }}
              transition={{ duration: 0.7 }}
            >
              <div className="flex flex-col md:flex-row items-center gap-8">
                <div className="md:w-1/2">
                  <h2 className="text-3xl font-bold mb-6 text-white">
                    <span className="text-white opacity-50">Coming Soon:</span> <br/>
                    <span className="text-white">Growth Operating Platform</span>
                  </h2>
                  <p className="text-gray-400 mb-6">
                    We're building powerful tools to help you automate your outreach, manage your leads, and scale your business. Join our waitlist to be the first to know when we launch.
                  </p>
                  <div className="flex gap-4">
                    <span className="px-3 py-1 bg-blue-900/30 text-blue-400 rounded-full text-sm">In Development</span>
                    <span className="px-3 py-1 bg-gray-800 text-gray-400 rounded-full text-sm">Launch: Q3 2023</span>
                  </div>
                </div>
                <div className="md:w-1/2 mt-8 md:mt-0">
                  <div className="bg-gray-800 p-6 rounded-xl border border-gray-700 shadow-lg">
                    <div className="text-left mb-4">
                      <div className="flex items-center space-x-2 mb-2">
                        <div className="h-3 w-3 rounded-full bg-red-500"></div>
                        <div className="h-3 w-3 rounded-full bg-yellow-500"></div>
                        <div className="h-3 w-3 rounded-full bg-green-500"></div>
                      </div>
                      <p className="text-gray-400 text-sm mb-2">Message Template Builder</p>
                    </div>
                    <div className="border border-gray-700 rounded-lg p-4 bg-gray-900/70">
                      <p className="text-sm text-gray-300 font-mono">
                        Hey {"{{name}}"},<br/><br/>
                        I love your content about {"{{topic}}"}! Your {"{{recent_post}}"} really caught my attention.<br/><br/>
                        I'm reaching out because {"{{brand}}"} is looking for creators like you for our upcoming campaign.<br/><br/>
                        Would you be interested in a collaboration?<br/><br/>
                        {"{{signature}}"}
                      </p>
                    </div>
                    <div className="mt-4 flex gap-2">
                      <span className="px-3 py-1 bg-gray-700 text-white rounded-md text-xs">Name</span>
                      <span className="px-3 py-1 bg-gray-700 text-white rounded-md text-xs">Topic</span>
                      <span className="px-3 py-1 bg-gray-700 text-white rounded-md text-xs">+4 more</span>
                    </div>
                  </div>
                </div>
              </div>
            </motion.div>
          </div>
        </section>
        
        {/* CTA Section */}
        <section className="py-20 bg-black border-t border-gray-800">
          <div className="container mx-auto px-4">
            <motion.div 
              className="max-w-3xl mx-auto text-center"
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.7 }}
            >
              <h2 className="text-4xl font-bold mb-6 text-white">
                Ready to revolutionize your outreach?
              </h2>
              <p className="text-lg text-gray-300 mb-10">
                Join our waitlist today and be among the first to experience the future of growth operations.
              </p>
              <GradientBorderButton href="/signup" text="Get Started" isActive={true} />
            </motion.div>
          </div>
        </section>
      </main>

      <Footer />
    </div>
  );
} 