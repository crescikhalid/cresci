'use client';

import { useState } from 'react';
import Link from 'next/link';
import Navigation from '../components/Navigation';
import Footer from '../components/Footer';

interface LeadList {
  id: string;
  name: string;
  niche: string;
  count: number;
  date: string;
}

interface Campaign {
  id: string;
  name: string;
  status: 'active' | 'paused' | 'completed';
  leads: number;
  responses: number;
  date: string;
}

export default function Dashboard() {
  const [activeTab, setActiveTab] = useState<'lists' | 'campaigns'>('lists');

  // Mock data for lists
  const leadLists: LeadList[] = [
    { id: '1', name: 'Fitness Influencers', niche: 'Fitness', count: 126, date: '2023-10-15' },
    { id: '2', name: 'Beauty Bloggers', niche: 'Beauty', count: 87, date: '2023-10-10' },
    { id: '3', name: 'Tech Reviewers', niche: 'Technology', count: 54, date: '2023-10-05' },
  ];

  // Mock data for campaigns
  const campaigns: Campaign[] = [
    { id: '1', name: 'Summer Fitness Campaign', status: 'active', leads: 126, responses: 23, date: '2023-10-15' },
    { id: '2', name: 'Beauty Product Launch', status: 'completed', leads: 87, responses: 42, date: '2023-09-20' },
    { id: '3', name: 'Tech Gadget Promotion', status: 'paused', leads: 54, responses: 12, date: '2023-09-10' },
  ];

  return (
    <div className="flex flex-col min-h-screen bg-black">
      <Navigation />
      
      <main className="flex-grow pt-24 pb-20">
        <div className="container mx-auto px-4">
          {/* Dashboard Header */}
          <div className="mb-10">
            <h1 className="heading-lg mb-2">Dashboard</h1>
            <p className="text-gray-400">Manage your influencer lists and outreach campaigns</p>
          </div>
          
          {/* Stats Overview */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-10">
            <div className="card">
              <h3 className="text-lg font-medium mb-1">Total Leads</h3>
              <p className="text-4xl font-bold">267</p>
              <p className="text-gray-400 mt-2">Across 3 lists</p>
            </div>
            <div className="card">
              <h3 className="text-lg font-medium mb-1">Active Campaigns</h3>
              <p className="text-4xl font-bold">1</p>
              <p className="text-gray-400 mt-2">23 responses received</p>
            </div>
            <div className="card">
              <h3 className="text-lg font-medium mb-1">Response Rate</h3>
              <p className="text-4xl font-bold">18.9%</p>
              <p className="text-gray-400 mt-2">77 total responses</p>
            </div>
          </div>
          
          {/* Tab Navigation */}
          <div className="flex border-b border-gray-800 mb-8">
            <button
              className={`px-4 py-2 font-medium ${
                activeTab === 'lists'
                  ? 'text-white border-b-2 border-white'
                  : 'text-gray-400 hover:text-white'
              }`}
              onClick={() => setActiveTab('lists')}
            >
              Lead Lists
            </button>
            <button
              className={`px-4 py-2 font-medium ${
                activeTab === 'campaigns'
                  ? 'text-white border-b-2 border-white'
                  : 'text-gray-400 hover:text-white'
              }`}
              onClick={() => setActiveTab('campaigns')}
            >
              Campaigns
            </button>
          </div>
          
          {/* Action Buttons */}
          <div className="flex flex-col sm:flex-row gap-4 mb-8 justify-between items-center">
            <h2 className="heading-md">
              {activeTab === 'lists' ? 'Your Lead Lists' : 'Your Campaigns'}
            </h2>
            <div className="flex gap-4">
              <Link
                href={activeTab === 'lists' ? '/scrape' : '/message'}
                className="primary-button"
              >
                {activeTab === 'lists' ? 'Scrape New Leads' : 'Create Campaign'}
              </Link>
            </div>
          </div>
          
          {/* Content Based on Tab */}
          {activeTab === 'lists' ? (
            <div className="bg-gray-900/40 rounded-lg border border-gray-800 overflow-hidden">
              <table className="w-full">
                <thead>
                  <tr className="border-b border-gray-800">
                    <th className="py-3 px-4 text-left font-medium text-gray-300">Name</th>
                    <th className="py-3 px-4 text-left font-medium text-gray-300 hidden md:table-cell">Niche</th>
                    <th className="py-3 px-4 text-left font-medium text-gray-300">Leads</th>
                    <th className="py-3 px-4 text-left font-medium text-gray-300 hidden md:table-cell">Created</th>
                    <th className="py-3 px-4 text-left font-medium text-gray-300">Actions</th>
                  </tr>
                </thead>
                <tbody>
                  {leadLists.map((list) => (
                    <tr key={list.id} className="border-b border-gray-800 hover:bg-gray-800/50">
                      <td className="py-3 px-4">{list.name}</td>
                      <td className="py-3 px-4 hidden md:table-cell">{list.niche}</td>
                      <td className="py-3 px-4">{list.count}</td>
                      <td className="py-3 px-4 hidden md:table-cell">{list.date}</td>
                      <td className="py-3 px-4">
                        <div className="flex gap-2">
                          <button className="text-sm text-gray-400 hover:text-white">View</button>
                          <button className="text-sm text-gray-400 hover:text-white">Edit</button>
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          ) : (
            <div className="bg-gray-900/40 rounded-lg border border-gray-800 overflow-hidden">
              <table className="w-full">
                <thead>
                  <tr className="border-b border-gray-800">
                    <th className="py-3 px-4 text-left font-medium text-gray-300">Campaign</th>
                    <th className="py-3 px-4 text-left font-medium text-gray-300">Status</th>
                    <th className="py-3 px-4 text-left font-medium text-gray-300">Leads</th>
                    <th className="py-3 px-4 text-left font-medium text-gray-300 hidden md:table-cell">Responses</th>
                    <th className="py-3 px-4 text-left font-medium text-gray-300 hidden md:table-cell">Created</th>
                    <th className="py-3 px-4 text-left font-medium text-gray-300">Actions</th>
                  </tr>
                </thead>
                <tbody>
                  {campaigns.map((campaign) => (
                    <tr key={campaign.id} className="border-b border-gray-800 hover:bg-gray-800/50">
                      <td className="py-3 px-4">{campaign.name}</td>
                      <td className="py-3 px-4">
                        <span className={`inline-block px-2 py-1 rounded-full text-xs ${
                          campaign.status === 'active' 
                            ? 'bg-green-900/30 text-green-400' 
                            : campaign.status === 'paused'
                              ? 'bg-yellow-900/30 text-yellow-400'
                              : 'bg-gray-900/30 text-gray-400'
                        }`}>
                          {campaign.status}
                        </span>
                      </td>
                      <td className="py-3 px-4">{campaign.leads}</td>
                      <td className="py-3 px-4 hidden md:table-cell">{campaign.responses}</td>
                      <td className="py-3 px-4 hidden md:table-cell">{campaign.date}</td>
                      <td className="py-3 px-4">
                        <div className="flex gap-2">
                          <button className="text-sm text-gray-400 hover:text-white">View</button>
                          <button className="text-sm text-gray-400 hover:text-white">Edit</button>
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </div>
      </main>

      <Footer />
    </div>
  );
} 